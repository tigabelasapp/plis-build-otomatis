import React from 'react';
import { LaundryProvider, useLaundry } from './context/LaundryContext';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { MobileBottomNav } from './components/layout/MobileBottomNav';
import { MobileDrawer } from './components/layout/MobileDrawer';
import { DashboardView } from './components/views/DashboardView';
import { TransactionsView } from './components/views/TransactionsView';
import { CustomersView } from './components/views/CustomersView';
import { ProcessTrackingView } from './components/views/ProcessTrackingView';
import { PaymentsView } from './components/views/PaymentsView';
import { ExpensesView } from './components/views/ExpensesView';
import { ReportsView } from './components/views/ReportsView';
import { MasterDataView } from './components/views/MasterDataView';
import { SettingsView } from './components/views/SettingsView';
import { NewTransactionModal } from './components/modals/NewTransactionModal';
import { TransactionDetailModal } from './components/modals/TransactionDetailModal';
import { ThermalReceiptModal } from './components/modals/ThermalReceiptModal';

const MainLayout: React.FC = () => {
  const {
    activeTab,
    viewportMode,
    isNewTxModalOpen,
    setIsNewTxModalOpen,
    selectedTransactionId,
    setSelectedTransactionId,
    receiptModalTransaction,
    setReceiptModalTransaction,
  } = useLaundry();

  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView />;
      case 'transaksi':
        return <TransactionsView />;
      case 'pelanggan':
        return <CustomersView />;
      case 'proses_laundry':
        return <ProcessTrackingView />;
      case 'pembayaran':
        return <PaymentsView />;
      case 'pengeluaran':
        return <ExpensesView />;
      case 'laporan':
        return <ReportsView />;
      case 'master_data':
        return <MasterDataView />;
      case 'pengaturan':
        return <SettingsView />;
      default:
        return <DashboardView />;
    }
  };

  if (viewportMode === 'mobile') {
    return (
      <div className="min-h-screen bg-slate-200/70 py-0 sm:py-6 flex justify-center items-start text-slate-900 font-sans antialiased selection:bg-emerald-100">
        {/* Authentic Smartphone Shell Container */}
        <div className="w-full sm:max-w-[430px] min-h-screen sm:min-h-[860px] sm:max-h-[92vh] bg-slate-50 flex flex-col shadow-2xl sm:rounded-3xl sm:border border-slate-300/80 overflow-hidden relative">
          {/* Top Mobile Status Header */}
          <Navbar />

          {/* Scrollable Mobile Content Feed */}
          <main className="flex-1 overflow-y-auto px-4 py-4 pb-24">
            {renderActiveView()}
          </main>

          {/* Pinned Mobile Thumb Bottom Nav */}
          <MobileBottomNav />

          {/* Bottom Sheet Drawer for Additional Menus */}
          <MobileDrawer />
        </div>

        {/* Global Modals */}
        {isNewTxModalOpen && (
          <NewTransactionModal
            isOpen={isNewTxModalOpen}
            onClose={() => setIsNewTxModalOpen(false)}
          />
        )}

        {selectedTransactionId && (
          <TransactionDetailModal
            transactionId={selectedTransactionId}
            onClose={() => setSelectedTransactionId(null)}
          />
        )}

        {receiptModalTransaction && (
          <ThermalReceiptModal
            transaction={receiptModalTransaction}
            onClose={() => setReceiptModalTransaction(null)}
          />
        )}
      </div>
    );
  }

  // Desktop / Tablet Mode
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 font-sans antialiased">
      {/* Top Navbar */}
      <Navbar />

      {/* Main Content Split: Sidebar + Active View */}
      <div className="flex-1 flex flex-row overflow-hidden">
        {/* Navigation Sidebar */}
        <Sidebar />

        {/* Dynamic Workspace View */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8">
          <div className="max-w-7xl mx-auto">
            {renderActiveView()}
          </div>
        </main>
      </div>

      {/* Global Interactive Modals */}
      {isNewTxModalOpen && (
        <NewTransactionModal
          isOpen={isNewTxModalOpen}
          onClose={() => setIsNewTxModalOpen(false)}
        />
      )}

      {selectedTransactionId && (
        <TransactionDetailModal
          transactionId={selectedTransactionId}
          onClose={() => setSelectedTransactionId(null)}
        />
      )}

      {receiptModalTransaction && (
        <ThermalReceiptModal
          transaction={receiptModalTransaction}
          onClose={() => setReceiptModalTransaction(null)}
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <LaundryProvider>
      <MainLayout />
    </LaundryProvider>
  );
}
