import React, { useState } from 'react';
import { useLaundry } from '../../context/LaundryContext';
import { PaymentMethod } from '../../types';
import {
  formatRupiah,
  formatDateTime,
  getPaymentStatusBadgeClasses,
  getPaymentStatusLabel,
} from '../../utils/formatters';
import {
  CreditCard,
  Plus,
  Search,
  Eye,
  X,
} from 'lucide-react';

export const PaymentsView: React.FC = () => {
  const { transactions, payments, addPayment, setSelectedTransactionId } = useLaundry();

  const [activeTab, setActiveTab] = useState<'piutang' | 'riwayat'>('piutang');
  const [searchQuery, setSearchQuery] = useState('');

  // Payment Recording Modal State
  const [selectedTxIdForPay, setSelectedTxIdForPay] = useState<string | null>(null);
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payMethod, setPayMethod] = useState<PaymentMethod>('tunai');
  const [payNotes, setPayNotes] = useState<string>('');

  // Metrics
  const totalBilled = transactions.reduce((sum, t) => sum + t.grandTotal, 0);
  const totalCollected = payments.reduce((sum, p) => sum + p.amount, 0);
  const totalReceivables = Math.max(0, totalBilled - totalCollected);

  // Transactions with unpaid balance
  const unpaidTransactions = transactions.filter(
    (t) => t.paymentStatus === 'belum_bayar' || t.paymentStatus === 'sebagian'
  );

  const filteredUnpaid = unpaidTransactions.filter(
    (t) =>
      t.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.customerPhone.includes(searchQuery)
  );

  const filteredPayments = payments.filter(
    (p) =>
      p.transactionId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.customerName && p.customerName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (p.notes && p.notes.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const handleOpenPayModal = (txId: string, remaining: number) => {
    setSelectedTxIdForPay(txId);
    setPayAmount(remaining);
    setPayMethod('tunai');
    setPayNotes('Pelunasan tagihan');
  };

  const handleSavePayment = () => {
    if (!selectedTxIdForPay) return;
    if (payAmount <= 0) {
      alert('Jumlah pembayaran harus lebih dari Rp 0.');
      return;
    }

    const res = addPayment(selectedTxIdForPay, payAmount, payMethod, payNotes);
    if (res.success) {
      setSelectedTxIdForPay(null);
    } else {
      alert(res.error || 'Gagal mencatat pembayaran');
    }
  };

  const selectedTxObj = transactions.find((t) => t.id === selectedTxIdForPay);

  return (
    <div className="space-y-4">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-lg sm:text-xl font-bold tracking-tight text-slate-900">
            Manajemen Pembayaran & Kas Masuk
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Kelola piutang pelanggan, pencatatan termin pembayaran (DP / pelunasan), dan histori kas masuk.
          </p>
        </div>
      </div>

      {/* KPI Financial Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs col-span-1">
          <span className="text-[10px] sm:text-xs font-bold uppercase tracking-wider text-slate-500 block">
            Total Transaksi
          </span>
          <div className="text-base sm:text-2xl font-bold font-mono tracking-tight text-slate-900 mt-1 tabular-nums">
            {formatRupiah(totalBilled)}
          </div>
          <p className="text-[10px] text-slate-400 mt-0.5">
            {transactions.length} nota terbit
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs col-span-1">
          <span className="text-[10px] sm:text-xs font-bold uppercase tracking-wider text-slate-500 block">
            Kas Diterima
          </span>
          <div className="text-base sm:text-2xl font-bold font-mono tracking-tight text-emerald-600 mt-1 tabular-nums">
            {formatRupiah(totalCollected)}
          </div>
          <p className="text-[10px] text-emerald-700 mt-0.5 font-medium">
            Telah dibukukan
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs col-span-2 sm:col-span-1">
          <span className="text-[10px] sm:text-xs font-bold uppercase tracking-wider text-slate-500 block">
            Sisa Piutang Tagihan
          </span>
          <div className="text-base sm:text-2xl font-bold font-mono tracking-tight text-amber-700 mt-1 tabular-nums">
            {formatRupiah(totalReceivables)}
          </div>
          <p className="text-[10px] text-amber-800 mt-0.5 font-medium">
            {unpaidTransactions.length} nota belum lunas
          </p>
        </div>
      </div>

      {/* Navigation Tabs & Search */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg w-full sm:w-auto">
          <button
            onClick={() => setActiveTab('piutang')}
            className={`flex-1 sm:flex-initial px-3 sm:px-4 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer text-center ${
              activeTab === 'piutang'
                ? 'bg-white text-slate-900 font-bold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Piutang ({unpaidTransactions.length})
          </button>
          <button
            onClick={() => setActiveTab('riwayat')}
            className={`flex-1 sm:flex-initial px-3 sm:px-4 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer text-center ${
              activeTab === 'riwayat'
                ? 'bg-white text-slate-900 font-bold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Riwayat Kas ({payments.length})
          </button>
        </div>

        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari nota, pelanggan, atau catatan..."
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Tab 1: Piutang & Sisa Tagihan */}
      {activeTab === 'piutang' && (
        <>
          {filteredUnpaid.length === 0 ? (
            <div className="bg-white rounded-xl border border-slate-200/80 p-8 text-center text-xs text-slate-400">
              Hebat! Tidak ada piutang atau tagihan tertunda yang belum lunas.
            </div>
          ) : (
            <>
              {/* Mobile Cards for Piutang */}
              <div className="space-y-3 md:hidden">
                {filteredUnpaid.map((tx) => {
                  const remaining = Math.max(0, tx.grandTotal - tx.paidAmount);
                  return (
                    <div
                      key={tx.id}
                      className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-xs space-y-3"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-xs text-slate-900">
                          {tx.id}
                        </span>
                        <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${getPaymentStatusBadgeClasses(tx.paymentStatus)}`}>
                          {getPaymentStatusLabel(tx.paymentStatus)}
                        </span>
                      </div>

                      <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-xs space-y-1">
                        <div className="flex justify-between items-center">
                          <span className="font-semibold text-slate-900">{tx.customerName}</span>
                          <span className="font-mono text-slate-500 text-[11px]">{tx.customerPhone}</span>
                        </div>
                        <div className="flex justify-between text-[11px] text-slate-600 pt-1 border-t border-slate-200/60">
                          <span>Total: {formatRupiah(tx.grandTotal)}</span>
                          <span className="text-emerald-700">Sudah Bayar: {formatRupiah(tx.paidAmount)}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-1 border-t border-slate-100">
                        <div>
                          <span className="text-[10px] text-slate-400 block">Sisa Tagihan</span>
                          <span className="font-mono font-bold text-sm text-amber-800">
                            {formatRupiah(remaining)}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setSelectedTransactionId(tx.id)}
                            className="px-2.5 py-1.5 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-lg cursor-pointer"
                          >
                            Nota
                          </button>
                          <button
                            onClick={() => handleOpenPayModal(tx.id, remaining)}
                            className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-xs shadow-xs transition-colors cursor-pointer"
                          >
                            + Catat Bayar
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Desktop Table for Piutang */}
              <div className="hidden md:block bg-white rounded-xl border border-slate-200/80 shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold">
                        <th className="py-3 px-4">No. Nota</th>
                        <th className="py-3 px-4">Pelanggan</th>
                        <th className="py-3 px-4">Tanggal Nota</th>
                        <th className="py-3 px-4 text-right">Total Tagihan</th>
                        <th className="py-3 px-4 text-right">Telah Dibayar</th>
                        <th className="py-3 px-4 text-right">Sisa Tagihan</th>
                        <th className="py-3 px-4 text-center">Status</th>
                        <th className="py-3 px-4 text-center w-36">Aksi Kasir</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredUnpaid.map((tx) => {
                        const remaining = Math.max(0, tx.grandTotal - tx.paidAmount);

                        return (
                          <tr key={tx.id} className="hover:bg-slate-50/80 transition-colors">
                            <td className="py-3 px-4 font-mono font-bold text-slate-900">
                              {tx.id}
                            </td>
                            <td className="py-3 px-4">
                              <span className="font-semibold text-slate-900 block">{tx.customerName}</span>
                              <span className="text-[11px] text-slate-400 font-mono">{tx.customerPhone}</span>
                            </td>
                            <td className="py-3 px-4 font-mono text-slate-500 text-[11px]">
                              {formatDateTime(tx.createdAt)}
                            </td>
                            <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                              {formatRupiah(tx.grandTotal)}
                            </td>
                            <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-700 font-medium">
                              {formatRupiah(tx.paidAmount)}
                            </td>
                            <td className="py-3 px-4 text-right font-mono tabular-nums font-bold text-amber-800">
                              {formatRupiah(remaining)}
                            </td>
                            <td className="py-3 px-4 text-center">
                              <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${getPaymentStatusBadgeClasses(tx.paymentStatus)}`}>
                                {getPaymentStatusLabel(tx.paymentStatus)}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-center">
                              <div className="flex items-center justify-center gap-2">
                                <button
                                  onClick={() => handleOpenPayModal(tx.id, remaining)}
                                  className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md font-semibold text-xs shadow-xs transition-colors cursor-pointer"
                                >
                                  + Catat Bayar
                                </button>
                                <button
                                  onClick={() => setSelectedTransactionId(tx.id)}
                                  className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md transition-colors cursor-pointer"
                                  title="Detail Nota"
                                >
                                  <Eye className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </>
      )}

      {/* Tab 2: Riwayat Kas Masuk */}
      {activeTab === 'riwayat' && (
        <>
          {filteredPayments.length === 0 ? (
            <div className="bg-white rounded-xl border border-slate-200/80 p-8 text-center text-xs text-slate-400">
              Belum ada riwayat pembayaran yang tercatat.
            </div>
          ) : (
            <>
              {/* Mobile Cards for Payments */}
              <div className="space-y-3 md:hidden">
                {filteredPayments.map((p) => (
                  <div
                    key={p.id}
                    className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-xs space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[11px] text-slate-500">
                        {formatDateTime(p.date)}
                      </span>
                      <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-emerald-50 text-emerald-800 border border-emerald-200">
                        {p.method}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-xs">
                      <div>
                        <span className="font-semibold text-slate-900 block">{p.customerName || '-'}</span>
                        <button
                          onClick={() => setSelectedTransactionId(p.transactionId)}
                          className="font-mono text-[11px] text-slate-500 hover:text-emerald-700 underline cursor-pointer"
                        >
                          Nota: {p.transactionId}
                        </button>
                      </div>

                      <span className="font-mono font-bold text-sm text-emerald-700 tabular-nums">
                        {formatRupiah(p.amount)}
                      </span>
                    </div>

                    {p.notes && (
                      <p className="text-[11px] text-slate-500 italic pt-1 border-t border-slate-100">
                        {p.notes}
                      </p>
                    )}
                  </div>
                ))}
              </div>

              {/* Desktop Table for Payments */}
              <div className="hidden md:block bg-white rounded-xl border border-slate-200/80 shadow-xs overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold">
                        <th className="py-3 px-4">Waktu Kas Masuk</th>
                        <th className="py-3 px-4">ID Nota Referensi</th>
                        <th className="py-3 px-4">Pelanggan</th>
                        <th className="py-3 px-4">Metode Bayar</th>
                        <th className="py-3 px-4">Keterangan</th>
                        <th className="py-3 px-4 text-right">Nominal Masuk</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredPayments.map((p) => (
                        <tr key={p.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="py-3 px-4 font-mono text-slate-600 text-[11px]">
                            {formatDateTime(p.date)}
                          </td>
                          <td className="py-3 px-4 font-mono font-bold text-slate-900">
                            <button
                              onClick={() => setSelectedTransactionId(p.transactionId)}
                              className="hover:text-emerald-700 cursor-pointer"
                            >
                              {p.transactionId}
                            </button>
                          </td>
                          <td className="py-3 px-4 text-slate-800 font-medium">
                            {p.customerName || '-'}
                          </td>
                          <td className="py-3 px-4 uppercase font-semibold text-slate-700">
                            {p.method}
                          </td>
                          <td className="py-3 px-4 text-slate-600">{p.notes || '-'}</td>
                          <td className="py-3 px-4 text-right font-mono font-bold tabular-nums text-emerald-700 text-sm">
                            {formatRupiah(p.amount)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </>
      )}

      {/* Record Payment Modal */}
      {selectedTxIdForPay && selectedTxObj && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">
                Pencatatan Pembayaran: {selectedTxObj.id}
              </h3>
              <button
                onClick={() => setSelectedTxIdForPay(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Pelanggan:</span>
                  <span className="font-semibold text-slate-900">{selectedTxObj.customerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Total Tagihan:</span>
                  <span className="font-mono">{formatRupiah(selectedTxObj.grandTotal)}</span>
                </div>
                <div className="flex justify-between font-bold text-slate-900 border-t border-slate-200 pt-1">
                  <span>Sisa Tagihan Saat Ini:</span>
                  <span className="font-mono text-amber-800">
                    {formatRupiah(Math.max(0, selectedTxObj.grandTotal - selectedTxObj.paidAmount))}
                  </span>
                </div>
              </div>

              <div>
                <label className="font-medium text-slate-700 block mb-1">
                  Nominal Pembayaran Diterima (Rp) *
                </label>
                <input
                  type="number"
                  min="1"
                  value={payAmount}
                  onChange={(e) => setPayAmount(parseInt(e.target.value, 10) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-slate-900 focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-medium text-slate-700 block mb-1">
                  Metode Pembayaran *
                </label>
                <select
                  value={payMethod}
                  onChange={(e) => setPayMethod(e.target.value as PaymentMethod)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                >
                  <option value="tunai">Tunai (Cash Kasir)</option>
                  <option value="qris">QRIS Statis</option>
                  <option value="transfer">Transfer Bank</option>
                </select>
              </div>

              <div>
                <label className="font-medium text-slate-700 block mb-1">
                  Catatan / Keterangan
                </label>
                <input
                  type="text"
                  value={payNotes}
                  onChange={(e) => setPayNotes(e.target.value)}
                  placeholder="Misal: Pelunasan saat cucian diambil"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setSelectedTxIdForPay(null)}
                  className="px-3 py-1.5 text-slate-600 hover:text-slate-800 text-xs font-medium cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={handleSavePayment}
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-xs cursor-pointer"
                >
                  Simpan Pembayaran Masuk
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
