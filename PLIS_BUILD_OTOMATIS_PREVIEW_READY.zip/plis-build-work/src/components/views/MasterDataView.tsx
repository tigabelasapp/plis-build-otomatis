import React, { useState } from 'react';
import { useLaundry } from '../../context/LaundryContext';
import { ServiceMaster, ServiceCategory, ServiceUnit } from '../../types';
import { formatRupiah } from '../../utils/formatters';
import {
  Package,
  Plus,
  Search,
  Edit2,
  Trash2,
  X,
  Clock,
  Sparkles,
} from 'lucide-react';

const CATEGORIES: ServiceCategory[] = [
  'Kiloan',
  'Satuan',
  'Express',
  'Sepatu & Tas',
  'Dry Clean',
  'Karpet & Gorden',
  'Lainnya',
];

const UNITS: ServiceUnit[] = ['kg', 'pcs', 'pasang', 'set', 'm²', 'meter'];

export const MasterDataView: React.FC = () => {
  const { services, addService, updateService, deleteService } = useLaundry();

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('semua');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingService, setEditingService] = useState<ServiceMaster | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [category, setCategory] = useState<ServiceCategory>('Kiloan');
  const [unit, setUnit] = useState<ServiceUnit>('kg');
  const [pricePerUnit, setPricePerUnit] = useState<number>(0);
  const [defaultDurationHours, setDefaultDurationHours] = useState<number>(24);
  const [description, setDescription] = useState('');

  const filteredServices = services.filter((s) => {
    if (selectedCategory !== 'semua' && s.category !== selectedCategory) {
      return false;
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      return (
        s.name.toLowerCase().includes(q) ||
        (s.description && s.description.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const handleOpenAdd = () => {
    setEditingService(null);
    setName('');
    setCategory('Kiloan');
    setUnit('kg');
    setPricePerUnit(10000);
    setDefaultDurationHours(48);
    setDescription('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (srv: ServiceMaster) => {
    setEditingService(srv);
    setName(srv.name);
    setCategory(srv.category);
    setUnit(srv.unit);
    setPricePerUnit(srv.pricePerUnit);
    setDefaultDurationHours(srv.defaultDurationHours);
    setDescription(srv.description || '');
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Nama layanan wajib diisi.');
      return;
    }
    if (pricePerUnit <= 0) {
      alert('Tarif harga harus lebih dari Rp 0.');
      return;
    }

    if (editingService) {
      updateService({
        ...editingService,
        name: name.trim(),
        category,
        unit,
        pricePerUnit: Number(pricePerUnit),
        defaultDurationHours: Number(defaultDurationHours),
        description: description.trim() || undefined,
      });
    } else {
      addService({
        name: name.trim(),
        category,
        unit,
        pricePerUnit: Number(pricePerUnit),
        defaultDurationHours: Number(defaultDurationHours),
        description: description.trim() || undefined,
      });
    }

    setIsModalOpen(false);
  };

  const handleDelete = (srv: ServiceMaster) => {
    if (confirm(`Hapus layanan "${srv.name}" dari master data?`)) {
      deleteService(srv.id);
    }
  };

  return (
    <div className="space-y-5">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Master Data Layanan & Tarif Laundry
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Kelola katalog layanan, satuan ukur (kg, pcs, set, m²), harga dasar, dan durasi pengerjaan standar.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ Tambah Layanan Baru</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative flex-1 w-full max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari layanan laundry..."
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
          />
        </div>

        <div className="w-full sm:w-60">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
          >
            <option value="semua">Semua Kategori</option>
            {CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Services Table */}
      <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs overflow-hidden">
        {filteredServices.length === 0 ? (
          <div className="text-center py-12 text-xs text-slate-400">
            Tidak ada layanan yang sesuai filter.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold">
                  <th className="py-3 px-4">Nama Layanan</th>
                  <th className="py-3 px-4">Kategori</th>
                  <th className="py-3 px-4 text-center">Satuan</th>
                  <th className="py-3 px-4 text-right">Tarif Dasar</th>
                  <th className="py-3 px-4">Durasi Standar</th>
                  <th className="py-3 px-4 text-center w-24">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredServices.map((srv) => (
                  <tr key={srv.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4">
                      <span className="font-bold text-slate-900 block">{srv.name}</span>
                      {srv.description && (
                        <span className="text-[11px] text-slate-500 line-clamp-1">
                          {srv.description}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
                        {srv.category}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center font-mono font-bold text-slate-800">
                      /{srv.unit}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold tabular-nums text-emerald-700 text-sm">
                      {formatRupiah(srv.pricePerUnit)}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600">
                      <span className="flex items-center gap-1 text-[11px]">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span>{srv.defaultDurationHours} Jam ({Math.round(srv.defaultDurationHours / 24)} hari)</span>
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => handleOpenEdit(srv)}
                          className="p-1.5 text-slate-400 hover:text-slate-700 rounded-md transition-colors cursor-pointer"
                          title="Edit Layanan"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(srv)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded-md transition-colors cursor-pointer"
                          title="Hapus Layanan"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Service Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">
                {editingService ? 'Edit Layanan Master' : 'Tambah Layanan Laundry Baru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="font-medium text-slate-700 block mb-1">
                  Nama Layanan *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Contoh: Cuci Komplit Reguler"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-medium text-slate-700 block mb-1">Kategori *</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ServiceCategory)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white focus:outline-none"
                  >
                    {CATEGORIES.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-medium text-slate-700 block mb-1">Satuan Ukur *</label>
                  <select
                    value={unit}
                    onChange={(e) => setUnit(e.target.value as ServiceUnit)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white focus:outline-none font-mono"
                  >
                    {UNITS.map((u) => (
                      <option key={u} value={u}>
                        {u}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-medium text-slate-700 block mb-1">
                    Tarif Harga Dasar (Rp) *
                  </label>
                  <input
                    type="number"
                    min="100"
                    required
                    value={pricePerUnit || ''}
                    onChange={(e) => setPricePerUnit(parseInt(e.target.value, 10) || 0)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-slate-900 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-medium text-slate-700 block mb-1">
                    Durasi Pengerjaan Standar (Jam)
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={defaultDurationHours || ''}
                    onChange={(e) => setDefaultDurationHours(parseInt(e.target.value, 10) || 1)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-medium text-slate-700 block mb-1">Deskripsi Layanan</label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Keterangan proses atau bahan yang digunakan..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 text-slate-600 hover:text-slate-800 text-xs font-medium cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-xs cursor-pointer"
                >
                  {editingService ? 'Simpan Perubahan' : 'Tambahkan Layanan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
