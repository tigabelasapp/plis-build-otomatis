import React, { useState, useMemo } from 'react';
import { useLaundry } from '../../context/LaundryContext';
import { PaymentStatus } from '../../types';
import {
  formatRupiah,
  formatDateTime,
  formatSimpleDate,
  getPaymentStatusBadgeClasses,
  getPaymentStatusLabel,
  getTransactionDerivedStatus,
  generateWhatsAppMessage,
} from '../../utils/formatters';
import {
  Search,
  Plus,
  Printer,
  Share2,
  Eye,
  Calendar,
  X,
  RotateCcw,
  SlidersHorizontal,
  TrendingUp,
  AlertCircle,
  Receipt,
} from 'lucide-react';

export const TransactionsView: React.FC = () => {
  const {
    transactions,
    settings,
    setIsNewTxModalOpen,
    setSelectedTransactionId,
    setReceiptModalTransaction,
  } = useLaundry();

  // Search & Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [paymentFilter, setPaymentFilter] = useState<'semua' | PaymentStatus>('semua');
  const [statusFilter, setStatusFilter] = useState<'semua' | 'antre' | 'proses' | 'siap' | 'selesai'>('semua');

  // Date Range States
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [datePreset, setDatePreset] = useState<'all' | 'today' | '7days' | 'this_month' | 'custom'>('all');

  // Quick Date Preset Handler
  const handleDatePreset = (preset: 'all' | 'today' | '7days' | 'this_month') => {
    setDatePreset(preset);
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const toDateInputVal = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

    if (preset === 'all') {
      setStartDate('');
      setEndDate('');
    } else if (preset === 'today') {
      const todayStr = toDateInputVal(now);
      setStartDate(todayStr);
      setEndDate(todayStr);
    } else if (preset === '7days') {
      const start = new Date(now);
      start.setDate(start.getDate() - 7);
      setStartDate(toDateInputVal(start));
      setEndDate(toDateInputVal(now));
    } else if (preset === 'this_month') {
      const start = new Date(now.getFullYear(), now.getMonth(), 1);
      setStartDate(toDateInputVal(start));
      setEndDate(toDateInputVal(now));
    }
  };

  // Custom Date Change Handler
  const handleCustomStartDate = (val: string) => {
    setStartDate(val);
    setDatePreset('custom');
  };

  const handleCustomEndDate = (val: string) => {
    setEndDate(val);
    setDatePreset('custom');
  };

  // Reset All Filters
  const handleResetFilters = () => {
    setSearchQuery('');
    setPaymentFilter('semua');
    setStatusFilter('semua');
    setStartDate('');
    setEndDate('');
    setDatePreset('all');
  };

  const isFilterActive =
    searchQuery.trim() !== '' ||
    paymentFilter !== 'semua' ||
    statusFilter !== 'semua' ||
    startDate !== '' ||
    endDate !== '';

  // Real-time filtering with useMemo
  const filteredTransactions = useMemo(() => {
    return transactions.filter((tx) => {
      // Real-time Search by Transaction ID or Customer Name (or phone)
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchesId = tx.id.toLowerCase().includes(query);
        const matchesName = tx.customerName.toLowerCase().includes(query);
        const matchesPhone = tx.customerPhone.includes(query);

        if (!matchesId && !matchesName && !matchesPhone) {
          return false;
        }
      }

      // Date Range Filter
      if (startDate || endDate) {
        const txDate = new Date(tx.createdAt);

        if (startDate) {
          const start = new Date(startDate);
          start.setHours(0, 0, 0, 0);
          if (txDate < start) return false;
        }

        if (endDate) {
          const end = new Date(endDate);
          end.setHours(23, 59, 59, 999);
          if (txDate > end) return false;
        }
      }

      // Payment Filter
      if (paymentFilter !== 'semua' && tx.paymentStatus !== paymentFilter) {
        return false;
      }

      // Progress Status Filter
      if (statusFilter !== 'semua') {
        const derived = getTransactionDerivedStatus(tx);
        if (statusFilter === 'selesai' && !derived.isAllDelivered) return false;
        if (statusFilter === 'siap' && !tx.items.some((i) => i.status === 'siap_diambil')) return false;
        if (statusFilter === 'proses' && !tx.items.some((i) => i.status === 'proses')) return false;
        if (statusFilter === 'antre' && !tx.items.some((i) => i.status === 'menunggu')) return false;
      }

      return true;
    });
  }, [transactions, searchQuery, startDate, endDate, paymentFilter, statusFilter]);

  // Aggregate Metrics for filtered transactions
  const totalFilteredSales = useMemo(() => {
    return filteredTransactions.reduce((sum, tx) => sum + tx.grandTotal, 0);
  }, [filteredTransactions]);

  const totalFilteredPaid = useMemo(() => {
    return filteredTransactions.reduce((sum, tx) => sum + tx.paidAmount, 0);
  }, [filteredTransactions]);

  const totalFilteredRemaining = Math.max(0, totalFilteredSales - totalFilteredPaid);

  const pendingFilteredCount = useMemo(() => {
    return filteredTransactions.filter(
      (tx) => tx.paymentStatus === 'belum_bayar' || tx.paymentStatus === 'sebagian'
    ).length;
  }, [filteredTransactions]);

  return (
    <div className="space-y-4">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-lg sm:text-xl font-bold tracking-tight text-slate-900">
            Daftar Transaksi & Nota Penjualan
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Pencarian real-time berdasarkan Nama / ID Nota, filter rentang tanggal, dan monitoring status.
          </p>
        </div>

        <button
          onClick={() => setIsNewTxModalOpen(true)}
          className="flex items-center justify-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer w-full sm:w-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ Transaksi Baru</span>
        </button>
      </div>

      {/* Top Summary Row: Total Revenue, Pending Payments, and Total Transactions Count */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Metric 1: Total Revenue */}
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">
              Total Pendapatan
            </span>
            <div className="text-xl sm:text-2xl font-bold font-mono tracking-tight text-slate-900 tabular-nums">
              {formatRupiah(totalFilteredSales)}
            </div>
            <p className="text-[10px] text-slate-400">
              {isFilterActive ? 'Sesuai filter pencarian saat ini' : 'Seluruh nilai transaksi'}
            </p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 2: Pending Payments */}
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">
              Pembayaran Tertunda
            </span>
            <div className="text-xl sm:text-2xl font-bold font-mono tracking-tight text-amber-700 tabular-nums">
              {formatRupiah(totalFilteredRemaining)}
            </div>
            <p className="text-[10px] text-amber-800 font-medium">
              {pendingFilteredCount} nota belum lunas
            </p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
            <AlertCircle className="w-5 h-5" />
          </div>
        </div>

        {/* Metric 3: Total Transactions Count */}
        <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">
              Total Transaksi
            </span>
            <div className="text-xl sm:text-2xl font-bold font-mono tracking-tight text-emerald-700 tabular-nums">
              {filteredTransactions.length} <span className="text-sm font-normal text-slate-500">Nota</span>
            </div>
            <p className="text-[10px] text-slate-400">
              {isFilterActive ? `Dari ${transactions.length} total nota` : 'Semua transaksi tercatat'}
            </p>
          </div>
          <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
            <Receipt className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Main Filter & Real-Time Search Box */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs space-y-3.5">
        {/* Row 1: Real-Time Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-emerald-600 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari real-time: Nama Pelanggan (misal: Budi) atau No. Nota (misal: PLIS-2610)..."
            className="w-full pl-10 pr-9 py-2.5 text-xs sm:text-sm border border-slate-300 rounded-xl bg-slate-50/50 focus:bg-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 focus:outline-none transition-all placeholder:text-slate-400 font-medium"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2.5 p-1 text-slate-400 hover:text-slate-600 rounded-md transition-colors cursor-pointer"
              title="Hapus pencarian"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Row 2: Date Range Picker & Date Presets */}
        <div className="p-3 bg-slate-50/80 rounded-xl border border-slate-200/70 space-y-2.5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <span className="text-[11px] font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-emerald-600" />
              <span>Rentang Tanggal Riwayat Nota:</span>
            </span>

            {/* Quick Date Presets */}
            <div className="flex flex-wrap items-center gap-1">
              <button
                type="button"
                onClick={() => handleDatePreset('all')}
                className={`px-2.5 py-1 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer ${
                  datePreset === 'all'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
                }`}
              >
                Semua
              </button>
              <button
                type="button"
                onClick={() => handleDatePreset('today')}
                className={`px-2.5 py-1 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer ${
                  datePreset === 'today'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
                }`}
              >
                Hari Ini
              </button>
              <button
                type="button"
                onClick={() => handleDatePreset('7days')}
                className={`px-2.5 py-1 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer ${
                  datePreset === '7days'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
                }`}
              >
                7 Hari Terakhir
              </button>
              <button
                type="button"
                onClick={() => handleDatePreset('this_month')}
                className={`px-2.5 py-1 text-[11px] font-semibold rounded-lg transition-colors cursor-pointer ${
                  datePreset === 'this_month'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200'
                }`}
              >
                Bulan Ini
              </button>
            </div>
          </div>

          {/* Date Range Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-slate-300">
              <span className="text-[11px] font-medium text-slate-500 shrink-0">Dari:</span>
              <input
                type="date"
                value={startDate}
                onChange={(e) => handleCustomStartDate(e.target.value)}
                className="w-full text-xs font-mono text-slate-800 focus:outline-none bg-transparent cursor-pointer"
              />
              {startDate && (
                <button
                  type="button"
                  onClick={() => {
                    setStartDate('');
                    setDatePreset('custom');
                  }}
                  className="text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 bg-white px-3 py-1.5 rounded-lg border border-slate-300">
              <span className="text-[11px] font-medium text-slate-500 shrink-0">Sampai:</span>
              <input
                type="date"
                value={endDate}
                onChange={(e) => handleCustomEndDate(e.target.value)}
                className="w-full text-xs font-mono text-slate-800 focus:outline-none bg-transparent cursor-pointer"
              />
              {endDate && (
                <button
                  type="button"
                  onClick={() => {
                    setEndDate('');
                    setDatePreset('custom');
                  }}
                  className="text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Row 3: Payment & Progress Filters + Reset */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5 items-center">
          {/* Payment Filter Tabs */}
          <div className="md:col-span-6 flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              onClick={() => setPaymentFilter('semua')}
              className={`flex-1 py-1 text-[11px] font-medium rounded-md transition-colors cursor-pointer text-center ${
                paymentFilter === 'semua'
                  ? 'bg-white text-slate-900 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Semua Bayar
            </button>
            <button
              onClick={() => setPaymentFilter('belum_bayar')}
              className={`flex-1 py-1 text-[11px] font-medium rounded-md transition-colors cursor-pointer text-center ${
                paymentFilter === 'belum_bayar'
                  ? 'bg-white text-rose-700 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Belum Lunas
            </button>
            <button
              onClick={() => setPaymentFilter('sebagian')}
              className={`flex-1 py-1 text-[11px] font-medium rounded-md transition-colors cursor-pointer text-center ${
                paymentFilter === 'sebagian'
                  ? 'bg-white text-amber-700 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              DP
            </button>
            <button
              onClick={() => setPaymentFilter('lunas')}
              className={`flex-1 py-1 text-[11px] font-medium rounded-md transition-colors cursor-pointer text-center ${
                paymentFilter === 'lunas'
                  ? 'bg-white text-emerald-700 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Lunas
            </button>
          </div>

          {/* Status Lifecycle Dropdown */}
          <div className="md:col-span-4">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full px-3 py-1.5 text-xs border border-slate-300 rounded-lg bg-white focus:ring-1 focus:ring-emerald-500 focus:outline-none cursor-pointer"
            >
              <option value="semua">Semua Status Pengerjaan</option>
              <option value="antre">Ada Item Menunggu</option>
              <option value="proses">Ada Item Dikerjakan</option>
              <option value="siap">Ada Item Siap Diambil</option>
              <option value="selesai">Selesai (Semua Diserahkan)</option>
            </select>
          </div>

          {/* Reset Button */}
          <div className="md:col-span-2">
            <button
              type="button"
              onClick={handleResetFilters}
              disabled={!isFilterActive}
              className={`w-full flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                isFilterActive
                  ? 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100 cursor-pointer'
                  : 'bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed opacity-60'
              }`}
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          </div>
        </div>

        {/* Filter Summary & Metrics Strip */}
        <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-slate-600">
            <span>Ditemukan: <strong className="text-slate-900 font-mono tabular-nums">{filteredTransactions.length}</strong> dari {transactions.length} nota</span>
            {isFilterActive && (
              <span className="text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-medium">
                Filter Aktif
              </span>
            )}
          </div>

          <div className="flex items-center gap-3 text-slate-600 text-[11px]">
            <span>Total Nilai: <strong className="text-slate-900 font-mono">{formatRupiah(totalFilteredSales)}</strong></span>
            <span>·</span>
            <span>Kas Masuk: <strong className="text-emerald-700 font-mono">{formatRupiah(totalFilteredPaid)}</strong></span>
            {totalFilteredRemaining > 0 && (
              <>
                <span>·</span>
                <span>Sisa: <strong className="text-amber-800 font-mono">{formatRupiah(totalFilteredRemaining)}</strong></span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Transactions List: Mobile Cards + Desktop Table */}
      {filteredTransactions.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200/80 shadow-xs text-center py-12 px-4 space-y-2">
          <Search className="w-8 h-8 text-slate-300 mx-auto" />
          <p className="text-xs font-semibold text-slate-700">
            Tidak ada transaksi yang sesuai dengan kriteria pencarian.
          </p>
          <p className="text-[11px] text-slate-400">
            Coba ubah kata kunci pencarian, sesuaikan rentang tanggal, atau tekan tombol Reset.
          </p>
          {isFilterActive && (
            <button
              onClick={handleResetFilters}
              className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Bersihkan Filter</span>
            </button>
          )}
        </div>
      ) : (
        <>
          {/* Mobile Native Cards List */}
          <div className="space-y-3 md:hidden">
            {filteredTransactions.map((tx) => {
              const derived = getTransactionDerivedStatus(tx);
              const remaining = Math.max(0, tx.grandTotal - tx.paidAmount);

              return (
                <div
                  key={tx.id}
                  className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-xs space-y-3 hover:border-slate-300 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-xs text-slate-900">
                          {tx.id}
                        </span>
                        <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${getPaymentStatusBadgeClasses(tx.paymentStatus)}`}>
                          {getPaymentStatusLabel(tx.paymentStatus)}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                        {formatDateTime(tx.createdAt)}
                      </div>
                    </div>

                    <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${derived.badgeClass}`}>
                      {derived.label}
                    </span>
                  </div>

                  <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-xs space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="font-semibold text-slate-900">{tx.customerName}</span>
                      <span className="font-mono text-slate-500 text-[11px]">{tx.customerPhone}</span>
                    </div>
                    <div className="text-[11px] text-slate-600 line-clamp-1">
                      {tx.items.length} Layanan: {tx.items.map((i) => i.serviceName).join(', ')}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 block">Total Tagihan</span>
                      <span className="font-mono font-bold text-slate-900 tabular-nums">
                        {formatRupiah(tx.grandTotal)}
                      </span>
                      {remaining > 0 && (
                        <span className="text-[10px] text-amber-700 block font-medium">
                          Sisa: {formatRupiah(remaining)}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => setSelectedTransactionId(tx.id)}
                        className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold transition-colors cursor-pointer"
                      >
                        Detail
                      </button>

                      <button
                        onClick={() => setReceiptModalTransaction(tx)}
                        className="p-2 text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 bg-slate-50 rounded-lg border border-slate-200 transition-colors cursor-pointer"
                        title="Struk Kasir"
                      >
                        <Printer className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => {
                          const text = generateWhatsAppMessage(tx, settings);
                          window.open(`https://wa.me/${tx.customerPhone.replace(/[^0-9]/g, '')}?text=${text}`, '_blank');
                        }}
                        className="p-2 text-emerald-700 hover:bg-emerald-100 bg-emerald-50 rounded-lg border border-emerald-200 transition-colors cursor-pointer"
                        title="Kirim WhatsApp"
                      >
                        <Share2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Desktop Table View */}
          <div className="hidden md:block bg-white rounded-xl border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-600 border-b border-slate-200 font-semibold">
                    <th className="py-3 px-4">No. Nota</th>
                    <th className="py-3 px-4">Pelanggan</th>
                    <th className="py-3 px-4">Tanggal Masuk</th>
                    <th className="py-3 px-4">Item & Progres</th>
                    <th className="py-3 px-4 text-right">Tagihan & Sisa</th>
                    <th className="py-3 px-4 text-center">Status Bayar</th>
                    <th className="py-3 px-4 text-center w-36">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredTransactions.map((tx) => {
                    const derived = getTransactionDerivedStatus(tx);
                    const remaining = Math.max(0, tx.grandTotal - tx.paidAmount);

                    return (
                      <tr
                        key={tx.id}
                        className="hover:bg-slate-50/80 transition-colors group"
                      >
                        {/* ID Nota */}
                        <td className="py-3 px-4 font-mono font-bold text-slate-900 group-hover:text-emerald-600">
                          {tx.id}
                        </td>

                        {/* Customer Info */}
                        <td className="py-3 px-4">
                          <span className="font-semibold text-slate-900 block">{tx.customerName}</span>
                          <span className="text-[11px] text-slate-400 font-mono">{tx.customerPhone}</span>
                        </td>

                        {/* Date */}
                        <td className="py-3 px-4 text-slate-600 font-mono text-[11px]">
                          {formatDateTime(tx.createdAt)}
                        </td>

                        {/* Items & Status Breakdown */}
                        <td className="py-3 px-4">
                          <div className="flex flex-col gap-1">
                            <span className={`text-[10px] px-2 py-0.5 rounded font-medium w-fit ${derived.badgeClass}`}>
                              {derived.label}
                            </span>
                            <span className="text-[11px] text-slate-500">
                              {tx.items.length} item ({tx.items.map((i) => i.serviceName).join(', ')})
                            </span>
                          </div>
                        </td>

                        {/* Totals */}
                        <td className="py-3 px-4 text-right font-mono tabular-nums">
                          <div className="font-bold text-slate-900">{formatRupiah(tx.grandTotal)}</div>
                          {remaining > 0 ? (
                            <div className="text-[11px] text-amber-700 font-medium">
                              Sisa: {formatRupiah(remaining)}
                            </div>
                          ) : (
                            <div className="text-[11px] text-emerald-600">Lunas</div>
                          )}
                        </td>

                        {/* Payment Status Badge */}
                        <td className="py-3 px-4 text-center">
                          <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${getPaymentStatusBadgeClasses(tx.paymentStatus)}`}>
                            {getPaymentStatusLabel(tx.paymentStatus)}
                          </span>
                        </td>

                        {/* Actions */}
                        <td className="py-3 px-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => setSelectedTransactionId(tx.id)}
                              className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
                              title="Buka Detail Nota"
                            >
                              <Eye className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => setReceiptModalTransaction(tx)}
                              className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-md transition-colors cursor-pointer"
                              title="Cetak Struk Kasir (Thermal)"
                            >
                              <Printer className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => {
                                const text = generateWhatsAppMessage(tx, settings);
                                window.open(`https://wa.me/${tx.customerPhone.replace(/[^0-9]/g, '')}?text=${text}`, '_blank');
                              }}
                              className="p-1.5 text-slate-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-md transition-colors cursor-pointer"
                              title="Kirim Nota ke WhatsApp"
                            >
                              <Share2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
