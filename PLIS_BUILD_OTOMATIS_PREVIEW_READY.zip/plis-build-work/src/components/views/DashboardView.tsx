import React from 'react';
import { useLaundry } from '../../context/LaundryContext';
import {
  formatRupiah,
  formatDateTime,
  getItemStatusBadgeClasses,
  getItemStatusLabel,
  getPaymentStatusBadgeClasses,
  getPaymentStatusLabel,
  getTransactionDerivedStatus,
} from '../../utils/formatters';
import {
  TrendingUp,
  Clock,
  PackageCheck,
  CreditCard,
  Plus,
  ArrowRight,
  Layers,
  Wallet,
  Sparkles,
} from 'lucide-react';

export const DashboardView: React.FC = () => {
  const {
    transactions,
    payments,
    expenses,
    setActiveTab,
    setIsNewTxModalOpen,
    setSelectedTransactionId,
  } = useLaundry();

  // Metrics calculation
  const totalReceivables = transactions.reduce((acc, t) => {
    return acc + Math.max(0, t.grandTotal - t.paidAmount);
  }, 0);

  // Total payments collected
  const totalIncome = payments.reduce((acc, p) => acc + p.amount, 0);

  // Total expenses
  const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);

  // All individual items across all transactions
  const allItems = transactions.flatMap((t) =>
    t.items.map((i) => ({ ...i, transactionId: t.id, customerName: t.customerName }))
  );

  const waitingItems = allItems.filter((i) => i.status === 'menunggu');
  const workingItems = allItems.filter((i) => i.status === 'proses');
  const completedItems = allItems.filter((i) => i.status === 'selesai');
  const readyItems = allItems.filter((i) => i.status === 'siap_diambil');
  const deliveredItems = allItems.filter((i) => i.status === 'diserahkan');

  const activeProcessingCount = waitingItems.length + workingItems.length + completedItems.length;

  return (
    <div className="space-y-6">
      {/* Top Banner / Welcome with Quick Actions */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white rounded-2xl p-6 shadow-sm border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30 font-medium">
              Sistem Aktif & Terintegrasi
            </span>
            <span className="text-xs text-slate-400">· Operasional Real-Time</span>
          </div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Pusat Kendali Operasional Laundry
          </h1>
          <p className="text-xs text-slate-300 max-w-xl">
            Pantau arus kas, perjalanan pengerjaan per-item layanan, antrean serah terima, dan pencatatan transaksi secara presisi.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            onClick={() => setIsNewTxModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Transaksi Baru</span>
          </button>

          <button
            onClick={() => setActiveTab('proses_laundry')}
            className="flex items-center gap-2 px-3.5 py-2.5 bg-slate-800/80 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl border border-slate-700 transition-colors cursor-pointer"
          >
            <Layers className="w-4 h-4 text-emerald-400" />
            <span>Papan Pengerjaan</span>
          </button>
        </div>
      </div>

      {/* 4 Primary KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Kas Masuk */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Total Kas Diterima
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono tracking-tight text-slate-900 tabular-nums">
              {formatRupiah(totalIncome)}
            </div>
            <p className="text-[11px] text-slate-500 mt-1">
              Dari {payments.length} catatan pembayaran
            </p>
          </div>
        </div>

        {/* KPI 2: Cucian Sedang Dikerjakan */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Item Dalam Pengerjaan
            </span>
            <div className="w-8 h-8 rounded-lg bg-sky-50 text-sky-600 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono tracking-tight text-slate-900 tabular-nums">
              {activeProcessingCount} <span className="text-sm font-normal text-slate-500">item</span>
            </div>
            <p className="text-[11px] text-sky-700 mt-1 font-medium">
              {workingItems.length} sedang dicuci / disetrika
            </p>
          </div>
        </div>

        {/* KPI 3: Siap Diambil Pelanggan */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Siap Diambil
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <PackageCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono tracking-tight text-emerald-600 tabular-nums">
              {readyItems.length} <span className="text-sm font-normal text-slate-500">item</span>
            </div>
            <button
              onClick={() => setActiveTab('proses_laundry')}
              className="text-[11px] text-emerald-700 hover:text-emerald-800 font-semibold mt-1 flex items-center gap-1 cursor-pointer"
            >
              <span>Lihat antrean serah terima</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* KPI 4: Sisa Tagihan (Piutang) */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Piutang Belum Lunas
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono tracking-tight text-amber-700 tabular-nums">
              {formatRupiah(totalReceivables)}
            </div>
            <button
              onClick={() => setActiveTab('pembayaran')}
              className="text-[11px] text-amber-800 hover:text-amber-900 font-semibold mt-1 flex items-center gap-1 cursor-pointer"
            >
              <span>Kelola sisa tagihan</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>

      {/* Item Pipeline Real-Time Tracker (User's 5 States) */}
      <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-slate-800">
              Pipeline Perjalanan Item Cucian
            </h2>
            <p className="text-xs text-slate-500">
              Distribusi status seluruh item layanan yang tercatat dalam sistem ({allItems.length} total item).
            </p>
          </div>

          <button
            onClick={() => setActiveTab('proses_laundry')}
            className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 cursor-pointer"
          >
            <span>Buka Monitoring Pengerjaan</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Pipeline 5-column stage cards */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {/* Stage 1: Menunggu */}
          <div className="p-3.5 rounded-lg bg-amber-50/60 border border-amber-200/80">
            <div className="flex justify-between items-center text-xs font-semibold text-amber-800">
              <span>Menunggu</span>
              <span className="font-mono tabular-nums font-bold text-sm">{waitingItems.length}</span>
            </div>
            <p className="text-[11px] text-amber-700/80 mt-1">Antrean mesin cuci</p>
          </div>

          {/* Stage 2: Sedang Dikerjakan */}
          <div className="p-3.5 rounded-lg bg-sky-50/60 border border-sky-200/80">
            <div className="flex justify-between items-center text-xs font-semibold text-sky-800">
              <span>Dikerjakan</span>
              <span className="font-mono tabular-nums font-bold text-sm">{workingItems.length}</span>
            </div>
            <p className="text-[11px] text-sky-700/80 mt-1">Cuci / Kering / Setrika</p>
          </div>

          {/* Stage 3: Selesai */}
          <div className="p-3.5 rounded-lg bg-indigo-50/60 border border-indigo-200/80">
            <div className="flex justify-between items-center text-xs font-semibold text-indigo-800">
              <span>Selesai</span>
              <span className="font-mono tabular-nums font-bold text-sm">{completedItems.length}</span>
            </div>
            <p className="text-[11px] text-indigo-700/80 mt-1">Finishing & Packing</p>
          </div>

          {/* Stage 4: Siap Diambil */}
          <div className="p-3.5 rounded-lg bg-emerald-50 border border-emerald-300">
            <div className="flex justify-between items-center text-xs font-bold text-emerald-900">
              <span>Siap Diambil</span>
              <span className="font-mono tabular-nums font-bold text-base text-emerald-700">{readyItems.length}</span>
            </div>
            <p className="text-[11px] text-emerald-800 mt-1">Siap diserahkan kasir</p>
          </div>

          {/* Stage 5: Diserahkan */}
          <div className="p-3.5 rounded-lg bg-slate-100 border border-slate-200">
            <div className="flex justify-between items-center text-xs font-semibold text-slate-700">
              <span>Diserahkan</span>
              <span className="font-mono tabular-nums font-bold text-sm">{deliveredItems.length}</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">Diterima pelanggan</p>
          </div>
        </div>
      </div>

      {/* Two Columns: Recent Transactions & Financial Quick Snapshot */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Recent Transactions Table */}
        <div className="lg:col-span-2 bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                Transaksi Terkini
              </h2>
              <p className="text-xs text-slate-500">
                Daftar nota penjualan terbaru beserta status pengerjaan item.
              </p>
            </div>
            <button
              onClick={() => setActiveTab('transaksi')}
              className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 cursor-pointer"
            >
              <span>Lihat Semua</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {transactions.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-400">
              Belum ada transaksi. Klik "+ Transaksi Baru" untuk membuat nota pertama.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 text-slate-600 border-b border-slate-200">
                    <th className="py-2.5 px-3 font-semibold">No. Nota</th>
                    <th className="py-2.5 px-3 font-semibold">Pelanggan</th>
                    <th className="py-2.5 px-3 font-semibold">Status Pengerjaan</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Tagihan</th>
                    <th className="py-2.5 px-3 font-semibold text-center">Status Bayar</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {transactions.slice(0, 5).map((tx) => {
                    const derived = getTransactionDerivedStatus(tx);
                    return (
                      <tr
                        key={tx.id}
                        onClick={() => setSelectedTransactionId(tx.id)}
                        className="hover:bg-slate-50/80 transition-colors cursor-pointer group"
                      >
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-900 group-hover:text-emerald-600">
                          {tx.id}
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="font-semibold text-slate-800 block">{tx.customerName}</span>
                          <span className="text-[11px] text-slate-400 font-mono">{tx.customerPhone}</span>
                        </td>
                        <td className="py-2.5 px-3">
                          <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${derived.badgeClass}`}>
                            {derived.label}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums text-slate-900">
                          {formatRupiah(tx.grandTotal)}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${getPaymentStatusBadgeClasses(tx.paymentStatus)}`}>
                            {getPaymentStatusLabel(tx.paymentStatus)}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Right Column: Mini Financial & Outflow Ledger */}
        <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider text-slate-800">
                Arus Kas Ringkas
              </h2>
              <p className="text-xs text-slate-500">Pemasukan kas vs pengeluaran usaha.</p>
            </div>
            <button
              onClick={() => setActiveTab('laporan')}
              className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 cursor-pointer"
            >
              Laporan Lengkap
            </button>
          </div>

          <div className="space-y-3">
            <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Total Pemasukan Kas:</span>
                <span className="font-mono font-bold text-emerald-700">{formatRupiah(totalIncome)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Total Pengeluaran:</span>
                <span className="font-mono font-bold text-rose-700">{formatRupiah(totalExpenses)}</span>
              </div>
              <div className="flex justify-between text-slate-900 font-bold border-t border-slate-200 pt-1.5 text-xs">
                <span>Laba Bersih Kas:</span>
                <span className={`font-mono text-sm ${totalIncome - totalExpenses >= 0 ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {formatRupiah(totalIncome - totalExpenses)}
                </span>
              </div>
            </div>

            <div className="pt-2">
              <div className="flex justify-between items-center text-xs font-bold text-slate-700 mb-2">
                <span>Pengeluaran Terkini</span>
                <button
                  onClick={() => setActiveTab('pengeluaran')}
                  className="text-[11px] text-emerald-600 hover:text-emerald-700 font-medium cursor-pointer"
                >
                  + Catat Biaya
                </button>
              </div>

              <div className="space-y-2">
                {expenses.slice(0, 3).map((exp) => (
                  <div key={exp.id} className="p-2.5 rounded-lg border border-slate-100 bg-slate-50/50 flex justify-between items-center text-xs">
                    <div className="space-y-0.5 truncate pr-2">
                      <p className="font-medium text-slate-900 truncate">{exp.description}</p>
                      <p className="text-[10px] text-slate-500">{exp.category}</p>
                    </div>
                    <span className="font-mono font-bold text-slate-800 tabular-nums shrink-0">
                      {formatRupiah(exp.amount)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
