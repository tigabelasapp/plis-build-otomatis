import React, { useState } from 'react';
import { useLaundry } from '../../context/LaundryContext';
import { Customer } from '../../types';
import { formatRupiah, formatSimpleDate } from '../../utils/formatters';
import {
  Users,
  Search,
  UserPlus,
  Phone,
  MapPin,
  FileText,
  Trash2,
  Edit2,
  X,
  History,
} from 'lucide-react';

export const CustomersView: React.FC = () => {
  const { customers, transactions, addCustomer, updateCustomer, deleteCustomer, setSelectedTransactionId } = useLaundry();

  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [viewHistoryCustId, setViewHistoryCustId] = useState<string | null>(null);

  // Form states
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');

  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search) ||
      c.address.toLowerCase().includes(search.toLowerCase())
  );

  const handleOpenAdd = () => {
    setEditingCustomer(null);
    setName('');
    setPhone('');
    setAddress('');
    setNotes('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (c: Customer) => {
    setEditingCustomer(c);
    setName(c.name);
    setPhone(c.phone);
    setAddress(c.address);
    setNotes(c.notes || '');
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Nama pelanggan tidak boleh kosong.');
      return;
    }

    if (editingCustomer) {
      updateCustomer({
        ...editingCustomer,
        name: name.trim(),
        phone: phone.trim() || '-',
        address: address.trim() || '-',
        notes: notes.trim() || undefined,
      });
    } else {
      addCustomer({
        name: name.trim(),
        phone: phone.trim() || '-',
        address: address.trim() || '-',
        notes: notes.trim() || undefined,
      });
    }

    setIsModalOpen(false);
  };

  const handleDelete = (c: Customer) => {
    if (confirm(`Hapus pelanggan ${c.name}? Histori transaksi terkait tetap tersimpan.`)) {
      deleteCustomer(c.id);
      if (viewHistoryCustId === c.id) setViewHistoryCustId(null);
    }
  };

  // Customer History list
  const selectedCustObj = customers.find((c) => c.id === viewHistoryCustId);
  const custTransactions = transactions.filter((t) => t.customerId === viewHistoryCustId);

  return (
    <div className="space-y-5">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Database Pelanggan Laundry
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Kelola data kontak, preferensi cucian, dan histori belanja pelanggan.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-xs transition-colors cursor-pointer self-start sm:self-auto"
        >
          <UserPlus className="w-4 h-4" />
          <span>+ Tambah Pelanggan</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-xs flex items-center justify-between gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Cari pelanggan berdasarkan nama, nomor telepon, atau alamat..."
            className="w-full pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
          />
        </div>

        <span className="text-xs text-slate-500 font-medium">
          Total: <strong className="text-slate-900 font-mono tabular-nums">{filteredCustomers.length}</strong> pelanggan
        </span>
      </div>

      {/* Grid of Customers */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCustomers.map((c) => {
          const userTxList = transactions.filter((t) => t.customerId === c.id);
          const totalSpent = userTxList.reduce((acc, t) => acc + t.grandTotal, 0);

          return (
            <div
              key={c.id}
              className="bg-white rounded-xl border border-slate-200/80 shadow-xs p-5 flex flex-col justify-between space-y-4 hover:border-slate-300 transition-colors"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900">{c.name}</h3>
                    <span className="text-[10px] text-slate-400 font-mono">ID: {c.id}</span>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(c)}
                      className="p-1 text-slate-400 hover:text-slate-700 rounded-md transition-colors cursor-pointer"
                      title="Edit Pelanggan"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(c)}
                      className="p-1 text-slate-400 hover:text-rose-600 rounded-md transition-colors cursor-pointer"
                      title="Hapus Pelanggan"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs text-slate-600">
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="font-mono">{c.phone}</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                    <span className="line-clamp-2">{c.address}</span>
                  </div>
                  {c.notes && (
                    <div className="p-2 rounded-md bg-amber-50/70 border border-amber-200/60 text-[11px] text-amber-800">
                      <strong>Catatan Khusus:</strong> {c.notes}
                    </div>
                  )}
                </div>
              </div>

              {/* Footer with transaction stats */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px]">Total Belanja</span>
                  <span className="font-mono font-bold text-emerald-700 tabular-nums">
                    {formatRupiah(totalSpent)}
                  </span>
                </div>

                <button
                  onClick={() => setViewHistoryCustId(c.id)}
                  className="flex items-center gap-1 text-[11px] font-semibold text-slate-700 hover:text-emerald-700 bg-slate-50 hover:bg-slate-100 px-2.5 py-1.5 rounded-md border border-slate-200 transition-colors cursor-pointer"
                >
                  <History className="w-3 h-3 text-slate-500" />
                  <span>{userTxList.length} Nota</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Customer Past Transactions Modal */}
      {viewHistoryCustId && selectedCustObj && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[85vh] flex flex-col overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  Histori Nota: {selectedCustObj.name}
                </h3>
                <p className="text-xs text-slate-500 font-mono">{selectedCustObj.phone}</p>
              </div>
              <button
                onClick={() => setViewHistoryCustId(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-3">
              {custTransactions.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-400">
                  Belum ada transaksi tercatat untuk pelanggan ini.
                </div>
              ) : (
                custTransactions.map((tx) => (
                  <div
                    key={tx.id}
                    onClick={() => {
                      setViewHistoryCustId(null);
                      setSelectedTransactionId(tx.id);
                    }}
                    className="p-3.5 bg-slate-50 hover:bg-slate-100 rounded-lg border border-slate-200 flex items-center justify-between cursor-pointer transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-xs text-slate-900">{tx.id}</span>
                        <span className="text-[10px] text-slate-500">
                          {formatSimpleDate(tx.createdAt)}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1">
                        {tx.items.map((i) => i.serviceName).join(', ')}
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="font-mono font-bold text-xs text-slate-900 block">
                        {formatRupiah(tx.grandTotal)}
                      </span>
                      <span className="text-[10px] uppercase font-semibold text-emerald-700">
                        {tx.paymentStatus}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="px-6 py-3 bg-white border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setViewHistoryCustId(null)}
                className="px-4 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Customer Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 bg-slate-50">
              <h3 className="text-sm font-bold text-slate-900">
                {editingCustomer ? 'Edit Data Pelanggan' : 'Tambah Pelanggan Baru'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="font-medium text-slate-700 block mb-1">Nama Lengkap *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Contoh: Budi Santoso"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-medium text-slate-700 block mb-1">No. WhatsApp / HP</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="081234567890"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-medium text-slate-700 block mb-1">Alamat Domisili</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Jl. Mawar No. 10..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="font-medium text-slate-700 block mb-1">Preferensi / Catatan Khusus</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Contoh: Suka pewangi lavender lembut, baju putih dipisahkan..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 text-slate-600 hover:text-slate-800 text-xs font-medium cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg shadow-xs cursor-pointer"
                >
                  {editingCustomer ? 'Simpan Perubahan' : 'Daftarkan Pelanggan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
