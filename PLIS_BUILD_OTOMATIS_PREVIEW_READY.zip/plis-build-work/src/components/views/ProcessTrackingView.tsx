import React, { useState } from 'react';
import { useLaundry } from '../../context/LaundryContext';
import { ItemStatus } from '../../types';
import {
  formatDateTime,
  formatRupiah,
  getItemStatusBadgeClasses,
  getItemStatusLabel,
} from '../../utils/formatters';
import {
  Layers,
  Clock,
  CheckCircle2,
  PackageCheck,
  ArrowRight,
  Filter,
  Search,
  ExternalLink,
  Phone,
  RotateCcw,
  Check,
  Sparkles,
} from 'lucide-react';

interface StageConfig {
  id: ItemStatus;
  label: string;
  stepNumber: number;
  shortDesc: string;
}

const STAGES: StageConfig[] = [
  { id: 'menunggu', label: 'Menunggu', stepNumber: 1, shortDesc: 'Antrean pengerjaan mesin' },
  { id: 'proses', label: 'Dikerjakan', stepNumber: 2, shortDesc: 'Sedang dicuci & dikeringkan' },
  { id: 'selesai', label: 'Selesai', stepNumber: 3, shortDesc: 'Finishing & quality control' },
  { id: 'siap_diambil', label: 'Siap Ambil', stepNumber: 4, shortDesc: 'Siap di rak pengambilan' },
  { id: 'diserahkan', label: 'Diserahkan', stepNumber: 5, shortDesc: 'Telah diserahkan ke pelanggan' },
];

const STAGE_INDEX_MAP: Record<ItemStatus, number> = {
  menunggu: 0,
  proses: 1,
  selesai: 2,
  siap_diambil: 3,
  diserahkan: 4,
};

const STAGE_PERCENTAGE: Record<ItemStatus, number> = {
  menunggu: 20,
  proses: 40,
  selesai: 60,
  siap_diambil: 80,
  diserahkan: 100,
};

interface ItemProgressBarProps {
  status: ItemStatus;
  onStepClick?: (targetStatus: ItemStatus) => void;
}

const ItemProgressBar: React.FC<ItemProgressBarProps> = ({ status, onStepClick }) => {
  const currentIndex = STAGE_INDEX_MAP[status] ?? 0;
  const currentStage = STAGES[currentIndex] || STAGES[0];
  const percent = STAGE_PERCENTAGE[status] ?? 20;

  const getTheme = () => {
    switch (status) {
      case 'menunggu':
        return {
          barColor: 'from-amber-400 to-amber-500',
          textColor: 'text-amber-800',
          bgColor: 'bg-amber-50',
          borderColor: 'border-amber-200',
          ringColor: 'ring-amber-400',
          activeNodeBg: 'bg-amber-500 text-white',
        };
      case 'proses':
        return {
          barColor: 'from-sky-400 to-sky-600',
          textColor: 'text-sky-800',
          bgColor: 'bg-sky-50',
          borderColor: 'border-sky-200',
          ringColor: 'ring-sky-400',
          activeNodeBg: 'bg-sky-600 text-white',
        };
      case 'selesai':
        return {
          barColor: 'from-indigo-400 to-indigo-600',
          textColor: 'text-indigo-800',
          bgColor: 'bg-indigo-50',
          borderColor: 'border-indigo-200',
          ringColor: 'ring-indigo-400',
          activeNodeBg: 'bg-indigo-600 text-white',
        };
      case 'siap_diambil':
        return {
          barColor: 'from-emerald-400 to-emerald-600',
          textColor: 'text-emerald-800',
          bgColor: 'bg-emerald-50',
          borderColor: 'border-emerald-300',
          ringColor: 'ring-emerald-400',
          activeNodeBg: 'bg-emerald-500 text-white',
        };
      case 'diserahkan':
        return {
          barColor: 'from-slate-600 to-emerald-600',
          textColor: 'text-slate-800',
          bgColor: 'bg-slate-100',
          borderColor: 'border-slate-300',
          ringColor: 'ring-emerald-500',
          activeNodeBg: 'bg-emerald-600 text-white',
        };
    }
  };

  const theme = getTheme();

  return (
    <div className="p-3 bg-slate-50/90 rounded-xl border border-slate-200/80 space-y-2.5">
      {/* Header Info */}
      <div className="flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5">
          <span className="font-semibold text-slate-700 text-[11px]">Progres Item:</span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${theme.bgColor} ${theme.textColor} ${theme.borderColor}`}>
            {currentStage.label}
          </span>
        </div>
        <div className="flex items-center gap-1 font-mono text-[11px] font-semibold text-slate-600">
          <span>Tahap {currentIndex + 1}/5</span>
          <span className="text-slate-400">({percent}%)</span>
        </div>
      </div>

      {/* Linear Progress Bar Track */}
      <div className="relative w-full bg-slate-200/90 h-2 rounded-full overflow-hidden">
        <div
          className={`h-full bg-gradient-to-r ${theme.barColor} rounded-full transition-all duration-500 ease-out`}
          style={{ width: `${percent}%` }}
        />
      </div>

      {/* 5-Step Milestones Stepper */}
      <div className="relative pt-1 pb-0.5">
        {/* Background Connecting Line */}
        <div className="absolute top-3.5 left-3 right-3 h-0.5 bg-slate-200 -z-0" />
        {/* Active Line Segment */}
        <div
          className={`absolute top-3.5 left-3 h-0.5 bg-gradient-to-r ${theme.barColor} -z-0 transition-all duration-500`}
          style={{ width: `calc(${((currentIndex) / 4) * 100}% - 12px)` }}
        />

        <div className="relative z-10 flex items-start justify-between">
          {STAGES.map((stage, idx) => {
            const isCompleted = idx < currentIndex;
            const isCurrent = idx === currentIndex;

            return (
              <button
                key={stage.id}
                type="button"
                onClick={() => onStepClick && onStepClick(stage.id)}
                title={`Pilih/ubah langsung ke tahap ${stage.label}: ${stage.shortDesc}`}
                className={`group flex flex-col items-center cursor-pointer focus:outline-none transition-transform hover:scale-105 ${
                  onStepClick ? 'cursor-pointer' : 'cursor-default'
                }`}
              >
                {/* Node Circle */}
                <div
                  className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold transition-all duration-300 ${
                    isCompleted
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : isCurrent
                      ? `${theme.activeNodeBg} ring-2 ring-offset-2 ${theme.ringColor} shadow-sm animate-pulse`
                      : 'bg-white text-slate-400 border border-slate-300'
                  }`}
                >
                  {isCompleted ? (
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  ) : (
                    <span>{stage.stepNumber}</span>
                  )}
                </div>

                {/* Node Label */}
                <span
                  className={`mt-1 text-[9px] sm:text-[10px] font-medium tracking-tight text-center max-w-[54px] leading-tight transition-colors ${
                    isCurrent
                      ? `font-bold ${theme.textColor}`
                      : isCompleted
                      ? 'text-slate-700 font-semibold'
                      : 'text-slate-400'
                  }`}
                >
                  {stage.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Contextual Description Note */}
      <div className="text-[11px] text-slate-500 bg-white/90 p-2 rounded-lg border border-slate-200/60 flex items-center gap-1.5">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0"></span>
        <span className="italic truncate">{currentStage.shortDesc}</span>
      </div>
    </div>
  );
};

export const ProcessTrackingView: React.FC = () => {
  const { transactions, updateItemStatus, deliverItem, setSelectedTransactionId } = useLaundry();

  const [activeStatusTab, setActiveStatusTab] = useState<'semua' | ItemStatus>('semua');
  const [searchQuery, setSearchQuery] = useState('');
  const [successBanner, setSuccessBanner] = useState<string | null>(null);

  // Flatten all items from all transactions with parent references
  const allItemsWithParent = transactions.flatMap((tx) =>
    tx.items.map((item) => ({
      ...item,
      transactionId: tx.id,
      customerName: tx.customerName,
      customerPhone: tx.customerPhone,
      parentTotalItems: tx.items.length,
      parentItemsStatuses: tx.items.map((i) => ({ name: i.serviceName, status: i.status })),
    }))
  );

  // Filter
  const filteredItems = allItemsWithParent.filter((item) => {
    if (activeStatusTab !== 'semua' && item.status !== activeStatusTab) {
      return false;
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      return (
        item.serviceName.toLowerCase().includes(q) ||
        item.transactionId.toLowerCase().includes(q) ||
        item.customerName.toLowerCase().includes(q) ||
        (item.notes && item.notes.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const countByStatus = {
    menunggu: allItemsWithParent.filter((i) => i.status === 'menunggu').length,
    proses: allItemsWithParent.filter((i) => i.status === 'proses').length,
    selesai: allItemsWithParent.filter((i) => i.status === 'selesai').length,
    siap_diambil: allItemsWithParent.filter((i) => i.status === 'siap_diambil').length,
    diserahkan: allItemsWithParent.filter((i) => i.status === 'diserahkan').length,
  };

  const handleAdvance = (txId: string, itemId: string, currentStatus: ItemStatus, itemName: string, custName: string) => {
    if (currentStatus === 'menunggu') {
      updateItemStatus(txId, itemId, 'proses');
      showTempBanner(`Item "${itemName}" milik ${custName} kini berstatus Sedang Dikerjakan.`);
    } else if (currentStatus === 'proses') {
      updateItemStatus(txId, itemId, 'selesai');
      showTempBanner(`Item "${itemName}" telah Selesai Dikerjakan & masuk tahap finishing.`);
    } else if (currentStatus === 'selesai') {
      updateItemStatus(txId, itemId, 'siap_diambil');
      showTempBanner(`Item "${itemName}" telah ditandai Siap Diambil.`);
    } else if (currentStatus === 'siap_diambil') {
      deliverItem(txId, itemId);
      showTempBanner(`Item "${itemName}" telah Diserahkan kepada ${custName}. Item lain dalam nota tetap berjalan.`);
    }
  };

  const handleRevert = (txId: string, itemId: string, currentStatus: ItemStatus) => {
    if (currentStatus === 'diserahkan') {
      updateItemStatus(txId, itemId, 'siap_diambil');
    } else if (currentStatus === 'siap_diambil') {
      updateItemStatus(txId, itemId, 'selesai');
    } else if (currentStatus === 'selesai') {
      updateItemStatus(txId, itemId, 'proses');
    } else if (currentStatus === 'proses') {
      updateItemStatus(txId, itemId, 'menunggu');
    }
  };

  const handleDirectStatusChange = (
    txId: string,
    itemId: string,
    targetStatus: ItemStatus,
    itemName: string,
    custName: string
  ) => {
    if (targetStatus === 'diserahkan') {
      deliverItem(txId, itemId);
      showTempBanner(`Item "${itemName}" milik ${custName} telah Diserahkan kepada pelanggan.`);
    } else {
      updateItemStatus(txId, itemId, targetStatus);
      showTempBanner(`Item "${itemName}" milik ${custName} diubah ke status ${getItemStatusLabel(targetStatus)}.`);
    }
  };

  const showTempBanner = (msg: string) => {
    setSuccessBanner(msg);
    setTimeout(() => setSuccessBanner(null), 4000);
  };

  return (
    <div className="space-y-5">
      {/* View Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Monitoring Pengerjaan Item Laundry
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Pelacakan perjalanan setiap item cucian secara independen: Menunggu ➔ Dikerjakan ➔ Selesai ➔ Siap Diambil ➔ Diserahkan.
          </p>
        </div>
      </div>

      {/* Success Notification Banner */}
      {successBanner && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-800 font-medium">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successBanner}</span>
          </div>
          <button
            onClick={() => setSuccessBanner(null)}
            className="text-emerald-600 hover:text-emerald-800 font-bold"
          >
            ✕
          </button>
        </div>
      )}

      {/* Filter and Tab Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/80 shadow-xs space-y-3">
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari item layanan, nomor nota, nama pelanggan, atau catatan..."
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
          />
        </div>

        {/* Status Filter Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-lg text-xs">
          <button
            onClick={() => setActiveStatusTab('semua')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              activeStatusTab === 'semua'
                ? 'bg-white text-slate-900 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Semua ({allItemsWithParent.length})
          </button>

          <button
            onClick={() => setActiveStatusTab('menunggu')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              activeStatusTab === 'menunggu'
                ? 'bg-white text-amber-800 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Menunggu ({countByStatus.menunggu})
          </button>

          <button
            onClick={() => setActiveStatusTab('proses')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              activeStatusTab === 'proses'
                ? 'bg-white text-sky-800 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Sedang Dikerjakan ({countByStatus.proses})
          </button>

          <button
            onClick={() => setActiveStatusTab('selesai')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              activeStatusTab === 'selesai'
                ? 'bg-white text-indigo-800 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Selesai Dikerjakan ({countByStatus.selesai})
          </button>

          <button
            onClick={() => setActiveStatusTab('siap_diambil')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              activeStatusTab === 'siap_diambil'
                ? 'bg-white text-emerald-800 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Siap Diambil ({countByStatus.siap_diambil})
          </button>

          <button
            onClick={() => setActiveStatusTab('diserahkan')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors cursor-pointer ${
              activeStatusTab === 'diserahkan'
                ? 'bg-white text-slate-900 font-semibold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Diserahkan ({countByStatus.diserahkan})
          </button>
        </div>
      </div>

      {/* Items Cards Grid */}
      {filteredItems.length === 0 ? (
        <div className="bg-white p-12 text-center rounded-xl border border-slate-200 text-xs text-slate-400">
          Tidak ada item cucian dalam kategori status ini.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredItems.map((item) => {
            const isReady = item.status === 'siap_diambil';
            const isDelivered = item.status === 'diserahkan';

            return (
              <div
                key={item.id}
                className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-4 flex flex-col justify-between space-y-4 hover:border-slate-300 transition-colors"
              >
                {/* Header: Nota ID & Parent Link */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <button
                      onClick={() => setSelectedTransactionId(item.transactionId)}
                      className="font-mono font-bold text-xs text-slate-900 hover:text-emerald-700 flex items-center gap-1 cursor-pointer"
                      title="Lihat Nota Lengkap"
                    >
                      <span>{item.transactionId}</span>
                      <ExternalLink className="w-3 h-3 text-slate-400" />
                    </button>

                    <span className={`text-[10px] px-2 py-0.5 rounded font-medium ${getItemStatusBadgeClasses(item.status)}`}>
                      {getItemStatusLabel(item.status)}
                    </span>
                  </div>

                  {/* Customer Info */}
                  <div className="text-xs text-slate-700 flex items-center justify-between">
                    <span className="font-semibold text-slate-900 truncate">
                      {item.customerName}
                    </span>
                    <span className="font-mono text-slate-500 text-[11px] shrink-0">
                      {item.customerPhone}
                    </span>
                  </div>

                  {/* Item Service Name & Details */}
                  <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-100 space-y-1">
                    <div className="text-xs font-bold text-slate-900">
                      {item.serviceName}
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span>Kuantitas: {item.quantity} {item.unit}</span>
                      <span className="font-bold text-slate-800">{formatRupiah(item.subtotal)}</span>
                    </div>

                    {item.notes && (
                      <p className="text-[11px] text-amber-800 italic pt-0.5 border-t border-slate-200/60">
                        Catatan: {item.notes}
                      </p>
                    )}
                  </div>

                  {/* Visual Process Progress Bar */}
                  <ItemProgressBar
                    status={item.status}
                    onStepClick={(targetStatus) =>
                      handleDirectStatusChange(
                        item.transactionId,
                        item.id,
                        targetStatus,
                        item.serviceName,
                        item.customerName
                      )
                    }
                  />

                  {/* Estimation Info */}
                  <div className="flex items-center gap-1 text-[11px] text-slate-500 font-mono">
                    <Clock className="w-3 h-3 text-slate-400 shrink-0" />
                    <span>Est. Selesai: {formatDateTime(item.estimatedCompletionDate)}</span>
                  </div>

                  {/* Context note if other items in same order exist */}
                  {item.parentTotalItems > 1 && (
                    <div className="text-[10px] text-slate-500 bg-slate-50/70 p-2 rounded border border-slate-200/50">
                      <span>Bagian dari nota multi-item ({item.parentTotalItems} item total). Item ini dapat diserahkan terpisah kapan pun siap.</span>
                    </div>
                  )}
                </div>

                {/* Footer Action Steppers */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  {/* Revert button (if needed to undo status) */}
                  {item.status !== 'menunggu' && (
                    <button
                      onClick={() => handleRevert(item.transactionId, item.id, item.status)}
                      className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
                      title="Kembalikan ke status sebelumnya"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {/* Forward button */}
                  <div className="flex-1 flex justify-end">
                    {item.status === 'menunggu' && (
                      <button
                        onClick={() => handleAdvance(item.transactionId, item.id, item.status, item.serviceName, item.customerName)}
                        className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                      >
                        <span>Mulai Kerjakan</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {item.status === 'proses' && (
                      <button
                        onClick={() => handleAdvance(item.transactionId, item.id, item.status, item.serviceName, item.customerName)}
                        className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Selesai Dikerjakan</span>
                      </button>
                    )}

                    {item.status === 'selesai' && (
                      <button
                        onClick={() => handleAdvance(item.transactionId, item.id, item.status, item.serviceName, item.customerName)}
                        className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                      >
                        <PackageCheck className="w-3.5 h-3.5" />
                        <span>Tandai Siap Diambil</span>
                      </button>
                    )}

                    {isReady && (
                      <button
                        onClick={() => handleAdvance(item.transactionId, item.id, item.status, item.serviceName, item.customerName)}
                        className="w-full flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-bold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg shadow-xs transition-colors cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4 text-emerald-900" />
                        <span>Serahkan ke Pelanggan</span>
                      </button>
                    )}

                    {isDelivered && (
                      <span className="text-xs text-slate-500 font-medium flex items-center gap-1 py-1">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Telah Diserahkan</span>
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
