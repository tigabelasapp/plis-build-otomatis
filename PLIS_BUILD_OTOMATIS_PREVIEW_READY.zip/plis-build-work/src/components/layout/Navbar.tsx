import React from 'react';
import { useLaundry } from '../../context/LaundryContext';
import { Plus, Smartphone, Monitor, ChevronLeft } from 'lucide-react';
import { PWAInstallButton } from '../pwa/PWAInstallButton';

export const Navbar: React.FC = () => {
  const {
    settings,
    setIsNewTxModalOpen,
    viewportMode,
    setViewportMode,
    activeTab,
    setActiveTab,
  } = useLaundry();

  const getTabTitle = () => {
    switch (activeTab) {
      case 'dashboard':
        return 'Beranda';
      case 'transaksi':
        return 'Transaksi';
      case 'pelanggan':
        return 'Pelanggan';
      case 'proses_laundry':
        return 'Pengerjaan';
      case 'pembayaran':
        return 'Pembayaran';
      case 'pengeluaran':
        return 'Pengeluaran';
      case 'laporan':
        return 'Laporan';
      case 'master_data':
        return 'Master Data';
      case 'pengaturan':
        return 'Pengaturan';
      default:
        return 'PLIS Laundry';
    }
  };

  return (
    <header className="px-4 py-3 bg-white border-b border-slate-200/90 shrink-0 sticky top-0 z-30 shadow-xs no-print">
      <div className="flex items-center justify-between gap-3 max-w-7xl mx-auto">
        {/* Left: Brand or Back button on mobile */}
        <div className="flex items-center gap-2.5">
          {viewportMode === 'mobile' && activeTab !== 'dashboard' ? (
            <button
              onClick={() => setActiveTab('dashboard')}
              className="flex items-center gap-1 text-xs font-semibold text-slate-700 hover:text-slate-900 p-1 -ml-1 rounded-md cursor-pointer"
            >
              <ChevronLeft className="w-5 h-5 text-slate-600" />
              <span>Kembali</span>
            </button>
          ) : (
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-base shadow-xs tracking-tight shrink-0">
                P
              </div>
              <div className="flex flex-col">
                <span className="text-sm font-bold tracking-tight text-slate-900 whitespace-nowrap leading-tight">
                  {settings.storeName}
                </span>
                <span className="text-[10px] text-slate-500 whitespace-nowrap leading-tight">
                  {viewportMode === 'mobile' ? getTabTitle() : (settings.storeTagline || 'Mobile POS Laundry')}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Center / Right: PWA Install + Mode Switcher + New Transaction */}
        <div className="flex items-center gap-2 shrink-0">
          {/* PWA Install Button */}
          <PWAInstallButton />

          {/* Mode Switcher Toggle Pill */}
          <div className="flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200 text-xs">
            <button
              type="button"
              onClick={() => setViewportMode('mobile')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all cursor-pointer ${
                viewportMode === 'mobile'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
              title="Tampilan HP Smartphone"
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
              <span>HP (Mobile)</span>
            </button>

            <button
              type="button"
              onClick={() => setViewportMode('desktop')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all cursor-pointer ${
                viewportMode === 'desktop'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
              title="Tampilan Luas Desktop / Tablet POS"
            >
              <Monitor className="w-3.5 h-3.5 text-slate-500" />
              <span className="hidden sm:inline">Tablet / PC</span>
            </button>
          </div>

          {/* Quick Action Button */}
          <button
            onClick={() => setIsNewTxModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-lg shadow-xs transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden xs:inline">+ Nota</span>
          </button>
        </div>
      </div>
    </header>
  );
};
