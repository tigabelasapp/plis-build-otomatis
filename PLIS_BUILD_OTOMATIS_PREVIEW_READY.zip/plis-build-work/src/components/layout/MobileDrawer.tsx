import React from 'react';
import { useLaundry } from '../../context/LaundryContext';
import { MainTab } from '../../types';
import {
  Users,
  Wallet,
  BarChart3,
  Package,
  Settings,
  Plus,
  X,
  ChevronRight,
  Store,
} from 'lucide-react';

export const MobileDrawer: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    isMobileMenuOpen,
    setIsMobileMenuOpen,
    setIsNewTxModalOpen,
    settings,
  } = useLaundry();

  if (!isMobileMenuOpen) return null;

  const menuItems: { id: MainTab; label: string; desc: string; icon: React.ComponentType<{ className?: string }> }[] = [
    {
      id: 'pelanggan',
      label: 'Data Pelanggan',
      desc: 'Buku kontak & riwayat belanja',
      icon: Users,
    },
    {
      id: 'pengeluaran',
      label: 'Pengeluaran Usaha',
      desc: 'Catat belanja bahan & listrik',
      icon: Wallet,
    },
    {
      id: 'laporan',
      label: 'Laporan Keuangan',
      desc: 'Omzet, arus kas & laba bersih',
      icon: BarChart3,
    },
    {
      id: 'master_data',
      label: 'Master Layanan & Tarif',
      desc: 'Kelola harga per kg/pcs & durasi',
      icon: Package,
    },
    {
      id: 'pengaturan',
      label: 'Pengaturan Outlet',
      desc: 'Profil toko, struk thermal & backup',
      icon: Settings,
    },
  ];

  const handleSelectTab = (tab: MainTab) => {
    setActiveTab(tab);
    setIsMobileMenuOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end bg-slate-900/60 backdrop-blur-xs no-print">
      {/* Tap backdrop to close */}
      <div className="flex-1" onClick={() => setIsMobileMenuOpen(false)} />

      {/* Bottom Sheet Modal */}
      <div className="bg-white rounded-t-3xl shadow-2xl max-w-md w-full mx-auto overflow-hidden border-t border-slate-200 max-h-[85vh] flex flex-col animate-in slide-in-from-bottom duration-200">
        {/* Grab Handle */}
        <div className="w-10 h-1 bg-slate-300 rounded-full mx-auto mt-3 mb-1 shrink-0" />

        {/* Sheet Header */}
        <div className="px-5 py-3 border-b border-slate-100 flex items-center justify-between shrink-0">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Menu Tambahan PLIS</h3>
            <p className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
              <Store className="w-3 h-3 text-emerald-600" />
              <span>{settings.storeName}</span>
            </p>
          </div>

          <button
            onClick={() => setIsMobileMenuOpen(false)}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Fast Action CTA */}
        <div className="p-4 bg-slate-50 border-b border-slate-100">
          <button
            onClick={() => {
              setIsMobileMenuOpen(false);
              setIsNewTxModalOpen(true);
            }}
            className="w-full h-11 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>+ Buat Transaksi Baru (POS Kasir)</span>
          </button>
        </div>

        {/* List of Other Menus */}
        <div className="p-3 space-y-1 overflow-y-auto flex-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleSelectTab(item.id)}
                className={`w-full flex items-center justify-between p-3 rounded-xl transition-colors cursor-pointer text-left ${
                  isActive
                    ? 'bg-emerald-50 text-emerald-950 font-semibold'
                    : 'hover:bg-slate-50 text-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      isActive
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold leading-tight">{item.label}</div>
                    <div className="text-[11px] text-slate-500 leading-tight mt-0.5">
                      {item.desc}
                    </div>
                  </div>
                </div>

                <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
              </button>
            );
          })}
        </div>

        {/* Bottom padding for safe area */}
        <div className="p-4 border-t border-slate-100 text-center text-[10px] text-slate-400">
          PLIS Laundry Mobile POS · v1.0
        </div>
      </div>
    </div>
  );
};
