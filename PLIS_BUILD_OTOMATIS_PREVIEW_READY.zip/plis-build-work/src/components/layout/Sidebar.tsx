import React from 'react';
import { useLaundry } from '../../context/LaundryContext';
import { MainTab } from '../../types';
import {
  LayoutDashboard,
  Receipt,
  Users,
  Layers,
  CreditCard,
  Wallet,
  BarChart3,
  Package,
  Settings,
  ChevronRight,
} from 'lucide-react';

interface NavItem {
  id: MainTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badgeCount?: number;
}

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, transactions } = useLaundry();

  // Calculate dynamic operational badges
  // 1. Items currently being washed or waiting
  const pendingOrWorkingItemsCount = transactions.reduce((acc, t) => {
    return acc + t.items.filter((i) => i.status === 'menunggu' || i.status === 'proses').length;
  }, 0);

  // 2. Items ready for pickup
  const readyForPickupCount = transactions.reduce((acc, t) => {
    return acc + t.items.filter((i) => i.status === 'siap_diambil').length;
  }, 0);

  // 3. Transactions with remaining debt
  const unpaidTransactionsCount = transactions.filter(
    (t) => t.paymentStatus === 'belum_bayar' || t.paymentStatus === 'sebagian'
  ).length;

  const navItems: NavItem[] = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'transaksi',
      label: 'Transaksi',
      icon: Receipt,
      badgeCount: transactions.length,
    },
    {
      id: 'pelanggan',
      label: 'Pelanggan',
      icon: Users,
    },
    {
      id: 'proses_laundry',
      label: 'Proses Laundry',
      icon: Layers,
      badgeCount: pendingOrWorkingItemsCount + readyForPickupCount,
    },
    {
      id: 'pembayaran',
      label: 'Pembayaran',
      icon: CreditCard,
      badgeCount: unpaidTransactionsCount,
    },
    {
      id: 'pengeluaran',
      label: 'Pengeluaran',
      icon: Wallet,
    },
    {
      id: 'laporan',
      label: 'Laporan',
      icon: BarChart3,
    },
    {
      id: 'master_data',
      label: 'Master Data',
      icon: Package,
    },
    {
      id: 'pengaturan',
      label: 'Pengaturan',
      icon: Settings,
    },
  ];

  return (
    <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col shrink-0 border-r border-slate-800 select-none no-print">
      {/* Sidebar Header / Quick Sub-Brand */}
      <div className="px-5 py-4 border-b border-slate-800/80 flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
          Menu Operasional
        </span>
        <span className="text-[10px] bg-slate-800 text-emerald-400 px-2 py-0.5 rounded font-mono">
          v1.0 Pro
        </span>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 px-3 py-3 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all group cursor-pointer ${
                isActive
                  ? 'bg-emerald-600 text-white font-semibold shadow-xs'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3 truncate">
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive ? 'text-white' : 'text-slate-400 group-hover:text-emerald-400'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                {item.badgeCount !== undefined && item.badgeCount > 0 && (
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded-md tabular-nums font-mono ${
                      isActive
                        ? 'bg-emerald-700 text-emerald-100'
                        : 'bg-slate-800 text-slate-300 group-hover:bg-slate-700'
                    }`}
                  >
                    {item.badgeCount}
                  </span>
                )}
                {isActive && <ChevronRight className="w-3.5 h-3.5 text-emerald-200" />}
              </div>
            </button>
          );
        })}
      </nav>

      {/* Bottom Summary Card */}
      <div className="p-4 m-3 rounded-lg bg-slate-800/80 border border-slate-700/60">
        <div className="flex items-center justify-between text-xs text-slate-300 mb-1.5">
          <span className="text-slate-400">Siap Diambil</span>
          <span className="font-semibold text-emerald-400 font-mono tabular-nums">
            {readyForPickupCount} item
          </span>
        </div>
        <div className="flex items-center justify-between text-xs text-slate-300">
          <span className="text-slate-400">Belum Lunas</span>
          <span className="font-semibold text-amber-400 font-mono tabular-nums">
            {unpaidTransactionsCount} nota
          </span>
        </div>
      </div>
    </aside>
  );
};
