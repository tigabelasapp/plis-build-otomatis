import React from 'react';
import { useLaundry } from '../../context/LaundryContext';
import { MainTab } from '../../types';
import {
  LayoutDashboard,
  Receipt,
  Layers,
  CreditCard,
  Menu,
} from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    transactions,
    isMobileMenuOpen,
    setIsMobileMenuOpen,
  } = useLaundry();

  // Dynamic badges
  const pendingOrWorkingCount = transactions.reduce((acc, t) => {
    return acc + t.items.filter((i) => i.status === 'menunggu' || i.status === 'proses' || i.status === 'siap_diambil').length;
  }, 0);

  const unpaidCount = transactions.filter(
    (t) => t.paymentStatus === 'belum_bayar' || t.paymentStatus === 'sebagian'
  ).length;

  const isMoreActive =
    activeTab === 'pelanggan' ||
    activeTab === 'pengeluaran' ||
    activeTab === 'laporan' ||
    activeTab === 'master_data' ||
    activeTab === 'pengaturan';

  const handleTabClick = (tab: MainTab) => {
    setActiveTab(tab);
    if (isMobileMenuOpen) setIsMobileMenuOpen(false);
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-lg no-print">
      <div className="max-w-md mx-auto grid grid-cols-5 items-center h-16 px-1">
        {/* Tab 1: Dashboard */}
        <button
          onClick={() => handleTabClick('dashboard')}
          className={`flex flex-col items-center justify-center py-1 transition-colors min-h-[44px] cursor-pointer ${
            activeTab === 'dashboard'
              ? 'text-emerald-600 font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <LayoutDashboard className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1">Beranda</span>
        </button>

        {/* Tab 2: Transaksi */}
        <button
          onClick={() => handleTabClick('transaksi')}
          className={`relative flex flex-col items-center justify-center py-1 transition-colors min-h-[44px] cursor-pointer ${
            activeTab === 'transaksi'
              ? 'text-emerald-600 font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <Receipt className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1">Transaksi</span>
          {transactions.length > 0 && (
            <span className="absolute top-1 right-3 text-[9px] bg-slate-200 text-slate-800 font-bold px-1 rounded-full font-mono">
              {transactions.length}
            </span>
          )}
        </button>

        {/* Tab 3: Pengerjaan */}
        <button
          onClick={() => handleTabClick('proses_laundry')}
          className={`relative flex flex-col items-center justify-center py-1 transition-colors min-h-[44px] cursor-pointer ${
            activeTab === 'proses_laundry'
              ? 'text-emerald-600 font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <Layers className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1">Pengerjaan</span>
          {pendingOrWorkingCount > 0 && (
            <span className="absolute top-1 right-2 text-[9px] bg-emerald-600 text-white font-bold px-1 rounded-full font-mono">
              {pendingOrWorkingCount}
            </span>
          )}
        </button>

        {/* Tab 4: Pembayaran */}
        <button
          onClick={() => handleTabClick('pembayaran')}
          className={`relative flex flex-col items-center justify-center py-1 transition-colors min-h-[44px] cursor-pointer ${
            activeTab === 'pembayaran'
              ? 'text-emerald-600 font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <CreditCard className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1">Bayar</span>
          {unpaidCount > 0 && (
            <span className="absolute top-1 right-3 text-[9px] bg-amber-500 text-white font-bold px-1 rounded-full font-mono">
              {unpaidCount}
            </span>
          )}
        </button>

        {/* Tab 5: Menu Lainnya (Drawer) */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className={`flex flex-col items-center justify-center py-1 transition-colors min-h-[44px] cursor-pointer ${
            isMoreActive || isMobileMenuOpen
              ? 'text-emerald-600 font-bold'
              : 'text-slate-500 hover:text-slate-900'
          }`}
        >
          <Menu className="w-5 h-5" />
          <span className="text-[10px] tracking-tight mt-1">Menu Lain</span>
        </button>
      </div>
    </nav>
  );
};
