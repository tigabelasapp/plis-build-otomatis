import React, { useState } from 'react';
import { useLaundry } from '../../context/LaundryContext';
import { ItemStatus, PaymentMethod } from '../../types';
import {
  formatRupiah,
  formatDateTime,
  getItemStatusLabel,
  getItemStatusBadgeClasses,
  getPaymentStatusLabel,
  getPaymentStatusBadgeClasses,
  getTransactionDerivedStatus,
  generateWhatsAppMessage,
} from '../../utils/formatters';
import {
  X,
  Printer,
  Share2,
  Trash2,
  CreditCard,
  CheckCircle2,
  Clock,
  ArrowRight,
  PackageCheck,
  AlertTriangle,
} from 'lucide-react';

interface Props {
  transactionId: string;
  onClose: () => void;
}

export const TransactionDetailModal: React.FC<Props> = ({ transactionId, onClose }) => {
  const {
    transactions,
    payments,
    settings,
    updateItemStatus,
    deliverItem,
    addPayment,
    deleteTransaction,
    setReceiptModalTransaction,
  } = useLaundry();

  const [isRecordingPayment, setIsRecordingPayment] = useState(false);
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payMethod, setPayMethod] = useState<PaymentMethod>('tunai');
  const [payNotes, setPayNotes] = useState<string>('');

  const tx = transactions.find((t) => t.id === transactionId);

  if (!tx) return null;

  const txPayments = payments.filter((p) => p.transactionId === tx.id);
  const remaining = Math.max(0, tx.grandTotal - tx.paidAmount);
  const derivedStatus = getTransactionDerivedStatus(tx);

  const handleNextStatus = (itemId: string, currentStatus: ItemStatus) => {
    switch (currentStatus) {
      case 'menunggu':
        updateItemStatus(tx.id, itemId, 'proses');
        break;
      case 'proses':
        updateItemStatus(tx.id, itemId, 'selesai');
        break;
      case 'selesai':
        updateItemStatus(tx.id, itemId, 'siap_diambil');
        break;
      case 'siap_diambil':
        deliverItem(tx.id, itemId);
        break;
    }
  };

  const handleSavePayment = () => {
    if (payAmount <= 0) {
      alert('Nominal pembayaran harus lebih besar dari Rp 0.');
      return;
    }
    addPayment(tx.id, payAmount, payMethod, payNotes);
    setIsRecordingPayment(false);
    setPayAmount(0);
    setPayNotes('');
  };

  const handleDelete = () => {
    if (confirm(`Yakin ingin menghapus nota transaksi ${tx.id}? Data yang dihapus tidak dapat dipulihkan.`)) {
      deleteTransaction(tx.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-bold text-slate-900 font-mono tracking-tight">
                  {tx.id}
                </span>
                <span className={`text-[11px] px-2 py-0.5 rounded font-medium ${derivedStatus.badgeClass}`}>
                  {derivedStatus.label}
                </span>
                <span className={`text-[11px] px-2 py-0.5 rounded font-medium ${getPaymentStatusBadgeClasses(tx.paymentStatus)}`}>
                  {getPaymentStatusLabel(tx.paymentStatus)}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Dibuat pada {formatDateTime(tx.createdAt)}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setReceiptModalTransaction(tx)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-100 rounded-lg border border-slate-300 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span>Cetak Struk Kasir</span>
            </button>

            <button
              onClick={() => {
                const text = generateWhatsAppMessage(tx, settings);
                window.open(`https://wa.me/${tx.customerPhone.replace(/[^0-9]/g, '')}?text=${text}`, '_blank');
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-200 transition-colors cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>Kirim WhatsApp</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Customer & Nota Info Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
              <span className="font-bold uppercase tracking-wider text-slate-700 block text-[11px]">
                Informasi Pelanggan
              </span>
              <div className="flex justify-between">
                <span className="text-slate-500">Nama:</span>
                <span className="font-semibold text-slate-900">{tx.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">No. WhatsApp:</span>
                <span className="font-mono text-slate-800">{tx.customerPhone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Alamat:</span>
                <span className="text-slate-800">{tx.customerAddress || '-'}</span>
              </div>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs">
              <span className="font-bold uppercase tracking-wider text-slate-700 block text-[11px]">
                Ringkasan Keuangan
              </span>
              <div className="flex justify-between">
                <span className="text-slate-500">Grand Total:</span>
                <span className="font-mono font-bold text-slate-900">{formatRupiah(tx.grandTotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Telah Dibayar:</span>
                <span className="font-mono text-emerald-700 font-semibold">{formatRupiah(tx.paidAmount)}</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-1">
                <span className="text-slate-700 font-semibold">Sisa Tagihan:</span>
                <span className={`font-mono font-bold ${remaining > 0 ? 'text-amber-800' : 'text-emerald-800'}`}>
                  {formatRupiah(remaining)}
                </span>
              </div>
            </div>
          </div>

          {/* Items Lifecycle Workflow Section */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Perjalanan Status Pengerjaan Tiap Item ({tx.items.length} Item)
                </h4>
                <p className="text-xs text-slate-500 mt-0.5">
                  Status berlaku per-item. Pelanggan boleh mengambil item yang sudah siap terlebih dahulu.
                </p>
              </div>
            </div>

            <div className="divide-y divide-slate-200 border border-slate-200 rounded-xl overflow-hidden bg-white">
              {tx.items.map((item, index) => {
                const isReady = item.status === 'siap_diambil';
                const isDelivered = item.status === 'diserahkan';

                return (
                  <div key={item.id} className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50/60 transition-colors">
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">
                          {index + 1}. {item.serviceName}
                        </span>
                        <span className={`text-[10px] px-2 py-0.5 rounded ${getItemStatusBadgeClasses(item.status)}`}>
                          {getItemStatusLabel(item.status)}
                        </span>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                        <span className="font-mono font-medium text-slate-700">
                          {item.quantity} {item.unit} @ {formatRupiah(item.pricePerUnit)}
                        </span>
                        <span>·</span>
                        <span className="font-mono font-bold text-slate-900">
                          Subtotal: {formatRupiah(item.subtotal)}
                        </span>
                        <span>·</span>
                        <span className="flex items-center gap-1 font-mono text-[11px] text-slate-600">
                          <Clock className="w-3 h-3 text-slate-400" />
                          <span>Est: {formatDateTime(item.estimatedCompletionDate)}</span>
                        </span>
                      </div>

                      {item.notes && (
                        <p className="text-xs text-amber-700 italic">
                          Catatan: {item.notes}
                        </p>
                      )}

                      {item.deliveredAt && (
                        <p className="text-[11px] text-slate-400 font-mono">
                          Diserahkan ke pelanggan pada: {formatDateTime(item.deliveredAt)}
                        </p>
                      )}
                    </div>

                    {/* Step Action Button */}
                    <div className="shrink-0 flex items-center gap-2">
                      {item.status === 'menunggu' && (
                        <button
                          onClick={() => handleNextStatus(item.id, 'menunggu')}
                          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                        >
                          <span>Mulai Kerjakan</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {item.status === 'proses' && (
                        <button
                          onClick={() => handleNextStatus(item.id, 'proses')}
                          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Selesai Dikerjakan</span>
                        </button>
                      )}

                      {item.status === 'selesai' && (
                        <button
                          onClick={() => handleNextStatus(item.id, 'selesai')}
                          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors cursor-pointer"
                        >
                          <PackageCheck className="w-3.5 h-3.5" />
                          <span>Tandai Siap Diambil</span>
                        </button>
                      )}

                      {isReady && (
                        <button
                          onClick={() => deliverItem(tx.id, item.id)}
                          className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-lg shadow-xs transition-colors cursor-pointer"
                        >
                          <CheckCircle2 className="w-4 h-4 text-emerald-900" />
                          <span>Serahkan Item Ini</span>
                        </button>
                      )}

                      {isDelivered && (
                        <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          <span>Telah Diserahkan</span>
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Payment History & Recording */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">
                  Riwayat Pembayaran & Kas Masuk
                </h4>
                <p className="text-xs text-slate-500">
                  Setiap pembayaran tercatat dengan tanggal dan metode.
                </p>
              </div>

              {remaining > 0 && !isRecordingPayment && (
                <button
                  onClick={() => {
                    setPayAmount(remaining);
                    setIsRecordingPayment(true);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-700 bg-emerald-100 hover:bg-emerald-200 rounded-lg transition-colors cursor-pointer"
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>+ Catat Pembayaran / Pelunasan</span>
                </button>
              )}
            </div>

            {/* Inline payment form if active */}
            {isRecordingPayment && (
              <div className="bg-white p-3.5 rounded-lg border border-emerald-300 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-800">
                    Pencatatan Pembayaran Tagihan
                  </span>
                  <button
                    onClick={() => setIsRecordingPayment(false)}
                    className="text-xs text-slate-500 hover:text-slate-700 underline cursor-pointer"
                  >
                    Batal
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[11px] font-medium text-slate-600 block mb-1">
                      Jumlah Bayar (Rp)
                    </label>
                    <input
                      type="number"
                      value={payAmount}
                      onChange={(e) => setPayAmount(parseInt(e.target.value, 10) || 0)}
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded font-mono font-bold focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-slate-600 block mb-1">
                      Metode
                    </label>
                    <select
                      value={payMethod}
                      onChange={(e) => setPayMethod(e.target.value as PaymentMethod)}
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded focus:outline-none"
                    >
                      <option value="tunai">Tunai (Cash)</option>
                      <option value="qris">QRIS Statis</option>
                      <option value="transfer">Transfer Bank</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-slate-600 block mb-1">
                      Keterangan
                    </label>
                    <input
                      type="text"
                      value={payNotes}
                      onChange={(e) => setPayNotes(e.target.value)}
                      placeholder="Misal: Pelunasan saat ambil baju"
                      className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    onClick={handleSavePayment}
                    className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-md shadow-xs cursor-pointer"
                  >
                    Simpan Pembayaran Masuk
                  </button>
                </div>
              </div>
            )}

            {/* Payments List */}
            {txPayments.length === 0 ? (
              <div className="text-xs text-slate-400 italic py-2 text-center bg-white rounded-lg border border-dashed border-slate-200">
                Belum ada catatan pembayaran untuk nota ini.
              </div>
            ) : (
              <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-600 border-b border-slate-200">
                      <th className="py-2 px-3 font-semibold">Tanggal</th>
                      <th className="py-2 px-3 font-semibold">Metode</th>
                      <th className="py-2 px-3 font-semibold">Keterangan</th>
                      <th className="py-2 px-3 font-semibold text-right">Nominal</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {txPayments.map((p) => (
                      <tr key={p.id}>
                        <td className="py-2 px-3 font-mono text-slate-600">
                          {formatDateTime(p.date)}
                        </td>
                        <td className="py-2 px-3 uppercase font-semibold text-slate-700">
                          {p.method}
                        </td>
                        <td className="py-2 px-3 text-slate-600">{p.notes || '-'}</td>
                        <td className="py-2 px-3 text-right font-mono font-bold text-emerald-700">
                          {formatRupiah(p.amount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-white border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={handleDelete}
            className="flex items-center gap-1.5 text-xs text-rose-600 hover:text-rose-700 font-medium cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Hapus Transaksi Ini</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
