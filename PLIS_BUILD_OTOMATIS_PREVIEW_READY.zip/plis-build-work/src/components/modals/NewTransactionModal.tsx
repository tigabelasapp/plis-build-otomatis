import React, { useState, useEffect } from 'react';
import { useLaundry } from '../../context/LaundryContext';
import { OrderItem, PaymentMethod, ServiceMaster, Customer } from '../../types';
import { formatRupiah } from '../../utils/formatters';
import {
  X,
  Plus,
  Trash2,
  Calendar,
  UserPlus,
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const NewTransactionModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const {
    customers,
    services,
    addCustomer,
    addTransaction,
    generateNextTransactionId,
    isTransactionIdAvailable,
    setReceiptModalTransaction,
    transactions,
  } = useLaundry();

  // Step 1: Customer state
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [customerSearch, setCustomerSearch] = useState<string>('');
  const [isAddingNewCustomer, setIsAddingNewCustomer] = useState(false);
  const [newCustName, setNewCustName] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustAddress, setNewCustAddress] = useState('');
  const [newCustNotes, setNewCustNotes] = useState('');

  // Step 2: Items Cart state
  const [items, setItems] = useState<OrderItem[]>([]);
  const [currentServiceId, setCurrentServiceId] = useState<string>('');
  const [currentQty, setCurrentQty] = useState<number>(1);
  const [currentItemNotes, setCurrentItemNotes] = useState<string>('');
  const [currentCustomEst, setCurrentCustomEst] = useState<string>('');

  // Step 3: Transaction ID management (Auto vs Manual)
  const [txId, setTxId] = useState<string>('');
  const [isManualId, setIsManualId] = useState<boolean>(false);
  const [idValidationMessage, setIdValidationMessage] = useState<{ isValid: boolean; text: string }>({
    isValid: true,
    text: '',
  });

  // Step 4: Discount & Notes
  const [discount, setDiscount] = useState<number>(0);
  const [orderNotes, setOrderNotes] = useState<string>('');

  // Step 5: Initial Payment state
  const [paymentOption, setPaymentOption] = useState<'belum_bayar' | 'dp' | 'lunas'>('belum_bayar');
  const [initialPayAmount, setInitialPayAmount] = useState<number>(0);
  const [initialPayMethod, setInitialPayMethod] = useState<PaymentMethod>('tunai');
  const [initialPayNotes, setInitialPayNotes] = useState<string>('');

  // Form error message
  const [errorMessage, setErrorMessage] = useState<string>('');

  // Initialize or reset when opened
  useEffect(() => {
    if (isOpen) {
      const generated = generateNextTransactionId();
      setTxId(generated);
      setIsManualId(false);
      setIdValidationMessage({ isValid: true, text: 'ID Nota tersedia & otomatis dibuat.' });
      setItems([]);
      setSelectedCustomerId('');
      setCustomerSearch('');
      setIsAddingNewCustomer(false);
      setDiscount(0);
      setOrderNotes('');
      setPaymentOption('belum_bayar');
      setInitialPayAmount(0);
      setInitialPayMethod('tunai');
      setErrorMessage('');

      // Set default selected service if available
      if (services.length > 0) {
        setCurrentServiceId(services[0].id);
        calculateDefaultEstDate(services[0].defaultDurationHours);
      }
    }
  }, [isOpen, transactions.length]);

  // Update default estimation when selected service changes
  useEffect(() => {
    const srv = services.find((s) => s.id === currentServiceId);
    if (srv) {
      calculateDefaultEstDate(srv.defaultDurationHours);
    }
  }, [currentServiceId, services]);

  const calculateDefaultEstDate = (hours: number) => {
    const d = new Date();
    d.setHours(d.getHours() + (hours || 24));
    // Format YYYY-MM-DDTHH:MM for datetime-local input
    const pad = (n: number) => String(n).padStart(2, '0');
    const localIso = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
      d.getHours()
    )}:${pad(d.getMinutes())}`;
    setCurrentCustomEst(localIso);
  };

  // Validate ID uniqueness dynamically when user types
  useEffect(() => {
    const clean = txId.trim();
    if (!clean) {
      setIdValidationMessage({ isValid: false, text: 'Nomor Nota tidak boleh kosong.' });
      return;
    }
    const available = isTransactionIdAvailable(clean);
    if (available) {
      setIdValidationMessage({ isValid: true, text: 'ID Nota unik dan siap digunakan.' });
    } else {
      setIdValidationMessage({
        isValid: false,
        text: `PERINGATAN: ID "${clean}" sudah pernah digunakan! Harap ganti ID lain.`,
      });
    }
  }, [txId]);

  if (!isOpen) return null;

  // Selected customer object
  const activeCustomer = customers.find((c) => c.id === selectedCustomerId);

  // Filtered customer search
  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(customerSearch.toLowerCase()) ||
      c.phone.includes(customerSearch)
  );

  // Subtotal calculation
  const subtotal = items.reduce((sum, item) => sum + item.subtotal, 0);
  const grandTotal = Math.max(0, subtotal - discount);

  // Adjust payment amount when payment option changes
  const handlePaymentOptionChange = (option: 'belum_bayar' | 'dp' | 'lunas') => {
    setPaymentOption(option);
    if (option === 'lunas') {
      setInitialPayAmount(grandTotal);
    } else if (option === 'dp') {
      // Default DP 50%
      setInitialPayAmount(Math.round(grandTotal * 0.5));
    } else {
      setInitialPayAmount(0);
    }
  };

  // Add Item to cart
  const handleAddItem = () => {
    const srv = services.find((s) => s.id === currentServiceId);
    if (!srv) return;

    if (currentQty <= 0) {
      alert('Kuantitas item harus lebih dari 0.');
      return;
    }

    const estIso = currentCustomEst ? new Date(currentCustomEst).toISOString() : new Date().toISOString();

    const newItem: OrderItem = {
      id: `ITEM-${Date.now()}-${items.length + 1}`,
      serviceId: srv.id,
      serviceName: srv.name,
      category: srv.category,
      quantity: Number(currentQty),
      unit: srv.unit,
      pricePerUnit: srv.pricePerUnit,
      subtotal: Math.round(Number(currentQty) * srv.pricePerUnit),
      estimatedCompletionDate: estIso,
      status: 'menunggu',
      notes: currentItemNotes.trim() || undefined,
    };

    setItems([...items, newItem]);
    setCurrentItemNotes('');
    // Keep quantity at 1 for next item
    setCurrentQty(1);
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  // Handle Quick Add New Customer
  const handleSaveNewCustomer = () => {
    if (!newCustName.trim()) {
      alert('Nama pelanggan wajib diisi.');
      return;
    }
    const created = addCustomer({
      name: newCustName.trim(),
      phone: newCustPhone.trim() || '-',
      address: newCustAddress.trim() || '-',
      notes: newCustNotes.trim() || undefined,
    });
    setSelectedCustomerId(created.id);
    setIsAddingNewCustomer(false);
    setNewCustName('');
    setNewCustPhone('');
    setNewCustAddress('');
    setNewCustNotes('');
  };

  // Submit and create transaction
  const handleSubmitTransaction = () => {
    setErrorMessage('');

    if (!selectedCustomerId && !activeCustomer) {
      setErrorMessage('Harap pilih atau daftarkan pelanggan terlebih dahulu.');
      return;
    }

    if (items.length === 0) {
      setErrorMessage('Harap tambahkan minimal satu item layanan ke dalam nota.');
      return;
    }

    if (!idValidationMessage.isValid) {
      setErrorMessage(idValidationMessage.text);
      return;
    }

    const cust = activeCustomer!;
    const nowIso = new Date().toISOString();

    const newTx = {
      id: txId.trim(),
      customerId: cust.id,
      customerName: cust.name,
      customerPhone: cust.phone,
      customerAddress: cust.address,
      createdAt: nowIso,
      items,
      totalAmount: subtotal,
      discount,
      grandTotal,
      paidAmount: 0,
      paymentStatus: 'belum_bayar' as const,
      notes: orderNotes.trim() || undefined,
    };

    const initialPaymentPayload =
      paymentOption !== 'belum_bayar' && initialPayAmount > 0
        ? {
            amount: initialPayAmount,
            method: initialPayMethod,
            notes: initialPayNotes || (paymentOption === 'lunas' ? 'Lunas saat transaksi dibuat' : 'Uang Muka (DP)'),
          }
        : undefined;

    const result = addTransaction(newTx, initialPaymentPayload);

    if (!result.success) {
      setErrorMessage(result.error || 'Terjadi kesalahan saat menyimpan transaksi.');
      return;
    }

    // Success! Prepare to show receipt modal immediately
    const savedTx = {
      ...newTx,
      paidAmount: initialPaymentPayload ? initialPaymentPayload.amount : 0,
      paymentStatus:
        initialPaymentPayload && initialPaymentPayload.amount >= grandTotal
          ? ('lunas' as const)
          : initialPaymentPayload && initialPaymentPayload.amount > 0
          ? ('sebagian' as const)
          : ('belum_bayar' as const),
    };

    onClose();
    setReceiptModalTransaction(savedTx);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full max-h-[92vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-bold text-slate-900">
                Buat Transaksi Penjualan Baru
              </span>
              <span className="text-xs bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded border border-emerald-200 font-mono font-medium">
                Alur POS Kasir
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Pilih pelanggan, masukkan item layanan, tetapkan ID unik, dan terbitkan nota.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body (Scrollable) */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2.5 text-xs text-rose-800 font-medium">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Section 1: Customer Selection */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="flex items-center justify-between mb-3">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <span>1. Data Pelanggan</span>
                <span className="text-rose-500">*</span>
              </label>

              {!isAddingNewCustomer && (
                <button
                  type="button"
                  onClick={() => setIsAddingNewCustomer(true)}
                  className="flex items-center gap-1 text-xs font-semibold text-emerald-600 hover:text-emerald-700 cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>+ Tambah Pelanggan Baru</span>
                </button>
              )}
            </div>

            {isAddingNewCustomer ? (
              /* Inline New Customer Form */
              <div className="bg-white p-4 rounded-lg border border-emerald-300 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-800">
                    Form Pendaftaran Pelanggan Baru
                  </span>
                  <button
                    type="button"
                    onClick={() => setIsAddingNewCustomer(false)}
                    className="text-xs text-slate-500 hover:text-slate-700 underline cursor-pointer"
                  >
                    Batal (Pilih Pelanggan Lama)
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-medium text-slate-700">Nama Lengkap *</label>
                    <input
                      type="text"
                      value={newCustName}
                      onChange={(e) => setNewCustName(e.target.value)}
                      placeholder="Contoh: Budi Santoso"
                      className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-medium text-slate-700">No. WhatsApp / HP</label>
                    <input
                      type="text"
                      value={newCustPhone}
                      onChange={(e) => setNewCustPhone(e.target.value)}
                      placeholder="Contoh: 08123456789"
                      className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-emerald-500 focus:outline-none font-mono"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <label className="text-[11px] font-medium text-slate-700">Alamat</label>
                    <input
                      type="text"
                      value={newCustAddress}
                      onChange={(e) => setNewCustAddress(e.target.value)}
                      placeholder="Alamat ringkas pelanggan"
                      className="mt-1 w-full px-3 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>
                <div className="flex justify-end pt-1">
                  <button
                    type="button"
                    onClick={handleSaveNewCustomer}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-md shadow-xs cursor-pointer"
                  >
                    Simpan & Pilih Pelanggan Ini
                  </button>
                </div>
              </div>
            ) : (
              /* Autocomplete / Select Dropdown */
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 items-center">
                <div>
                  <input
                    type="text"
                    value={customerSearch}
                    onChange={(e) => setCustomerSearch(e.target.value)}
                    placeholder="Ketik untuk mencari nama / no HP..."
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                  />
                </div>

                <div>
                  <select
                    value={selectedCustomerId}
                    onChange={(e) => setSelectedCustomerId(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                  >
                    <option value="">-- Pilih dari Daftar Pelanggan --</option>
                    {filteredCustomers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} ({c.phone})
                      </option>
                    ))}
                  </select>
                </div>

                {activeCustomer && (
                  <div className="md:col-span-2 text-xs text-slate-600 bg-white p-2.5 rounded-lg border border-slate-200 flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-slate-900">{activeCustomer.name}</span>
                      <span className="mx-2 text-slate-300">·</span>
                      <span className="font-mono text-slate-700">{activeCustomer.phone}</span>
                      <span className="mx-2 text-slate-300">·</span>
                      <span>{activeCustomer.address}</span>
                    </div>
                    {activeCustomer.notes && (
                      <span className="text-[11px] text-amber-700 italic">
                        Pref: {activeCustomer.notes}
                      </span>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Section 2: Tambah Item Layanan (Master & Cart) */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <span>2. Tambah Item Layanan Cucian</span>
                <span className="text-rose-500">*</span>
              </label>
              <span className="text-xs text-slate-500">
                Setiap item memiliki siklus status pengerjaan mandiri
              </span>
            </div>

            {/* Item Input Row */}
            <div className="bg-white p-3 rounded-lg border border-slate-200 grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
              {/* Service Select */}
              <div className="sm:col-span-4">
                <label className="text-[11px] font-medium text-slate-600 block mb-1">
                  Jenis Layanan (Master)
                </label>
                <select
                  value={currentServiceId}
                  onChange={(e) => setCurrentServiceId(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                >
                  {services.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} - {formatRupiah(s.pricePerUnit)}/{s.unit}
                    </option>
                  ))}
                </select>
              </div>

              {/* Quantity & Unit */}
              <div className="sm:col-span-2">
                <label className="text-[11px] font-medium text-slate-600 block mb-1">
                  Kuantitas ({services.find((s) => s.id === currentServiceId)?.unit || 'unit'})
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="0.1"
                  value={currentQty}
                  onChange={(e) => setCurrentQty(parseFloat(e.target.value) || 0)}
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md font-mono focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              {/* Estimated Completion */}
              <div className="sm:col-span-3">
                <label className="text-[11px] font-medium text-slate-600 block mb-1 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-400" />
                  <span>Estimasi Selesai</span>
                </label>
                <input
                  type="datetime-local"
                  value={currentCustomEst}
                  onChange={(e) => setCurrentCustomEst(e.target.value)}
                  className="w-full px-2 py-1 text-xs border border-slate-300 rounded-md font-mono focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              {/* Item Specific Notes */}
              <div className="sm:col-span-2">
                <label className="text-[11px] font-medium text-slate-600 block mb-1">
                  Catatan Item
                </label>
                <input
                  type="text"
                  value={currentItemNotes}
                  onChange={(e) => setCurrentItemNotes(e.target.value)}
                  placeholder="Misal: noda di kerah"
                  className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded-md focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                />
              </div>

              {/* Add Button */}
              <div className="sm:col-span-1">
                <button
                  type="button"
                  onClick={handleAddItem}
                  className="w-full h-8 flex items-center justify-center bg-slate-900 hover:bg-slate-800 text-white rounded-md text-xs font-semibold transition-colors cursor-pointer"
                  title="Tambah ke nota"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Cart Items List */}
            {items.length === 0 ? (
              <div className="text-center py-6 bg-white rounded-lg border border-dashed border-slate-300 text-xs text-slate-400">
                Belum ada item layanan di nota ini. Pilih layanan di atas dan klik tombol tambah (+).
              </div>
            ) : (
              <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-600 border-b border-slate-200">
                      <th className="py-2.5 px-3 font-semibold">Layanan</th>
                      <th className="py-2.5 px-3 font-semibold text-center">Kuantitas</th>
                      <th className="py-2.5 px-3 font-semibold text-right">Tarif</th>
                      <th className="py-2.5 px-3 font-semibold text-right">Subtotal</th>
                      <th className="py-2.5 px-3 font-semibold">Estimasi</th>
                      <th className="py-2.5 px-3 font-semibold text-center w-10">Aksi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {items.map((item, idx) => (
                      <tr key={item.id} className="hover:bg-slate-50/80">
                        <td className="py-2.5 px-3">
                          <div className="font-semibold text-slate-900">{item.serviceName}</div>
                          {item.notes && (
                            <div className="text-[11px] text-amber-700 italic">
                              Catatan: {item.notes}
                            </div>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-center font-mono">
                          {item.quantity} {item.unit}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                          {formatRupiah(item.pricePerUnit)}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums font-bold text-slate-900">
                          {formatRupiah(item.subtotal)}
                        </td>
                        <td className="py-2.5 px-3 text-[11px] text-slate-500 font-mono">
                          {new Date(item.estimatedCompletionDate).toLocaleDateString('id-ID', {
                            day: 'numeric',
                            month: 'short',
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <button
                            type="button"
                            onClick={() => handleRemoveItem(idx)}
                            className="p-1 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                            title="Hapus item ini"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Section 3: Penetapan ID Nota Unik & Permanen */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                <span>3. Nomor ID Nota Penjualan</span>
                <span className="text-rose-500">*</span>
              </label>

              <button
                type="button"
                onClick={() => setIsManualId(!isManualId)}
                className="text-xs text-emerald-700 hover:text-emerald-800 font-medium underline cursor-pointer"
              >
                {isManualId ? 'Gunakan ID Otomatis' : 'Ubah Manual (Khusus Owner)'}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 items-center">
              <div>
                <input
                  type="text"
                  value={txId}
                  onChange={(e) => setTxId(e.target.value.toUpperCase())}
                  disabled={!isManualId}
                  className={`w-full px-3 py-2 text-xs font-mono font-bold tracking-wider rounded-lg border ${
                    idValidationMessage.isValid
                      ? 'border-slate-300 bg-white text-slate-900'
                      : 'border-rose-400 bg-rose-50 text-rose-900'
                  } focus:ring-1 focus:ring-emerald-500 focus:outline-none`}
                />
              </div>

              <div className="flex items-center gap-2 text-xs">
                {idValidationMessage.isValid ? (
                  <span className="text-emerald-700 flex items-center gap-1.5 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{idValidationMessage.text}</span>
                  </span>
                ) : (
                  <span className="text-rose-700 flex items-center gap-1.5 font-semibold">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>{idValidationMessage.text}</span>
                  </span>
                )}
              </div>
            </div>
            <p className="text-[11px] text-slate-500 mt-2">
              Sesuai aturan: ID Nota ini bersifat permanen setelah diterbitkan dan tidak akan berubah meskipun nama pelanggan atau tanggal diedit.
            </p>
          </div>

          {/* Section 4: Ringkasan Total & Pembayaran Kasir */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-4">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block">
              4. Total Nota & Pencatatan Pembayaran Awal
            </label>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Left Column: Totals Calculation */}
              <div className="bg-white p-3.5 rounded-lg border border-slate-200 space-y-2 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal Item:</span>
                  <span className="font-mono tabular-nums">{formatRupiah(subtotal)}</span>
                </div>

                <div className="flex justify-between items-center text-slate-600">
                  <span>Potongan / Diskon:</span>
                  <div className="flex items-center gap-1 w-28">
                    <span className="text-slate-400">Rp</span>
                    <input
                      type="number"
                      min="0"
                      value={discount || ''}
                      onChange={(e) => setDiscount(Math.max(0, parseInt(e.target.value, 10) || 0))}
                      placeholder="0"
                      className="w-full px-1.5 py-1 text-xs border border-slate-300 rounded font-mono text-right focus:outline-none"
                    />
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs font-bold pt-2 border-t border-slate-200 text-slate-900">
                  <span>GRAND TOTAL:</span>
                  <span className="font-mono text-emerald-700 text-sm">{formatRupiah(grandTotal)}</span>
                </div>
              </div>

              {/* Middle Column: Payment Status Selector */}
              <div className="bg-white p-3.5 rounded-lg border border-slate-200 space-y-2.5 text-xs">
                <span className="font-semibold text-slate-700 block">Status Pembayaran Masuk:</span>

                <div className="space-y-1.5">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="paymentOption"
                      checked={paymentOption === 'belum_bayar'}
                      onChange={() => handlePaymentOptionChange('belum_bayar')}
                      className="text-emerald-600"
                    />
                    <span className="text-slate-800">Belum Dibayar (Bayar Nanti)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="paymentOption"
                      checked={paymentOption === 'dp'}
                      onChange={() => handlePaymentOptionChange('dp')}
                      className="text-emerald-600"
                    />
                    <span className="text-slate-800">Uang Muka / Sebagian (DP)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="paymentOption"
                      checked={paymentOption === 'lunas'}
                      onChange={() => handlePaymentOptionChange('lunas')}
                      className="text-emerald-600"
                    />
                    <span className="text-slate-800">Lunas Penuh Saat Drop Cucian</span>
                  </label>
                </div>
              </div>

              {/* Right Column: Payment Details */}
              <div className="bg-white p-3.5 rounded-lg border border-slate-200 space-y-2 text-xs">
                {paymentOption === 'belum_bayar' ? (
                  <div className="h-full flex flex-col justify-center text-center text-slate-500 py-2">
                    <p className="font-medium text-slate-700">Tagihan Belum Dibayar</p>
                    <p className="text-[11px] mt-1 text-slate-400">
                      Cucian tetap dapat diproses sesuai kebijakan usaha Anda.
                    </p>
                    <p className="text-xs font-mono font-bold text-amber-700 mt-2">
                      Sisa Tagihan: {formatRupiah(grandTotal)}
                    </p>
                  </div>
                ) : (
                  <>
                    <div>
                      <label className="text-[11px] font-medium text-slate-600 block mb-1">
                        Nominal Dibayar (Rp)
                      </label>
                      <input
                        type="number"
                        min="1"
                        value={initialPayAmount || ''}
                        onChange={(e) => setInitialPayAmount(parseInt(e.target.value, 10) || 0)}
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded font-mono font-bold text-slate-900 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="text-[11px] font-medium text-slate-600 block mb-1">
                        Metode Pembayaran
                      </label>
                      <select
                        value={initialPayMethod}
                        onChange={(e) => setInitialPayMethod(e.target.value as PaymentMethod)}
                        className="w-full px-2.5 py-1.5 text-xs border border-slate-300 rounded focus:outline-none"
                      >
                        <option value="tunai">Tunai (Cash Kasir)</option>
                        <option value="qris">QRIS Statis</option>
                        <option value="transfer">Transfer Bank</option>
                      </select>
                    </div>

                    <div className="flex justify-between items-center pt-1 border-t border-slate-100 text-[11px]">
                      <span className="text-slate-500">Sisa Tagihan:</span>
                      <span className="font-mono font-bold text-amber-700">
                        {formatRupiah(Math.max(0, grandTotal - initialPayAmount))}
                      </span>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer Bar */}
        <div className="px-6 py-4 bg-white border-t border-slate-200 flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-800 transition-colors cursor-pointer"
          >
            Batal
          </button>

          <button
            type="button"
            onClick={handleSubmitTransaction}
            disabled={!idValidationMessage.isValid || items.length === 0}
            className="flex items-center gap-2 px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Simpan & Terbitkan Nota</span>
          </button>
        </div>
      </div>
    </div>
  );
};
