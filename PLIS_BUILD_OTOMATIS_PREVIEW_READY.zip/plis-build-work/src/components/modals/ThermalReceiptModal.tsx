import React, { useState } from 'react';
import { useLaundry } from '../../context/LaundryContext';
import { Transaction } from '../../types';
import {
  formatRupiah,
  formatDateTime,
  getItemStatusLabel,
  generateWhatsAppMessage,
} from '../../utils/formatters';
import { Printer, Share2, X, Check, Copy } from 'lucide-react';

interface Props {
  transaction: Transaction;
  onClose: () => void;
}

export const ThermalReceiptModal: React.FC<Props> = ({ transaction, onClose }) => {
  const { settings } = useLaundry();
  const [copiedWA, setCopiedWA] = useState(false);

  const remaining = Math.max(0, transaction.grandTotal - transaction.paidAmount);
  const is58mm = settings.thermalWidth === '58mm';

  const handlePrint = () => {
    window.print();
  };

  const handleWhatsApp = () => {
    const text = generateWhatsAppMessage(transaction, settings);
    // Open whatsapp web / app
    const url = `https://wa.me/${transaction.customerPhone.replace(/[^0-9]/g, '')}?text=${text}`;
    window.open(url, '_blank');
  };

  const handleCopyText = () => {
    const text = decodeURIComponent(generateWhatsAppMessage(transaction, settings));
    navigator.clipboard.writeText(text);
    setCopiedWA(true);
    setTimeout(() => setCopiedWA(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full max-h-[90vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Header Modal Bar */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 bg-slate-50 no-print">
          <div className="flex items-center gap-2">
            <Printer className="w-4 h-4 text-emerald-600" />
            <h3 className="text-sm font-bold text-slate-800">
              Pratinjau Struk Kasir ({settings.thermalWidth})
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Receipt Preview Area */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-100 flex justify-center">
          {/* Authentic Thermal Paper Card */}
          <div
            id="thermal-receipt"
            className={`printable-area bg-white text-slate-900 p-5 shadow-sm border border-slate-200 font-mono text-xs leading-relaxed ${
              is58mm ? 'max-w-[280px] w-full text-[11px]' : 'max-w-[340px] w-full'
            }`}
          >
            {/* Store Header */}
            <div className="text-center pb-3 border-b border-dashed border-slate-400">
              <h2 className="text-sm font-bold uppercase tracking-tight text-slate-950">
                {settings.storeName}
              </h2>
              {settings.storeTagline && (
                <p className="text-[10px] text-slate-600 mt-0.5">{settings.storeTagline}</p>
              )}
              <p className="text-[10px] text-slate-600 mt-1">{settings.storeAddress}</p>
              <p className="text-[10px] text-slate-700 font-semibold">WA: {settings.storePhone}</p>
            </div>

            {/* Receipt Meta */}
            <div className="py-2.5 border-b border-dashed border-slate-400 space-y-1 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-600">No. Nota:</span>
                <span className="font-bold text-slate-950">{transaction.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Tanggal:</span>
                <span className="tabular-nums">{formatDateTime(transaction.createdAt)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">Pelanggan:</span>
                <span className="font-bold text-slate-950">{transaction.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-600">No. HP:</span>
                <span className="tabular-nums">{transaction.customerPhone}</span>
              </div>
            </div>

            {/* Items Table */}
            <div className="py-3 border-b border-dashed border-slate-400">
              <div className="text-[10px] uppercase font-bold text-slate-500 pb-1 border-b border-slate-200 flex justify-between">
                <span>Layanan / Item</span>
                <span>Subtotal</span>
              </div>

              <div className="divide-y divide-slate-100">
                {transaction.items.map((item, idx) => (
                  <div key={item.id || idx} className="py-2 space-y-0.5">
                    <div className="flex justify-between items-start font-medium text-slate-900">
                      <span className="pr-2">{item.serviceName}</span>
                      <span className="shrink-0 font-bold tabular-nums">
                        {formatRupiah(item.subtotal)}
                      </span>
                    </div>

                    <div className="flex justify-between text-[10px] text-slate-500">
                      <span>
                        {item.quantity} {item.unit} @ {formatRupiah(item.pricePerUnit)}
                      </span>
                      <span className="font-semibold text-emerald-800">
                        [{getItemStatusLabel(item.status)}]
                      </span>
                    </div>

                    {item.notes && (
                      <div className="text-[10px] text-slate-600 italic">
                        Catatan: {item.notes}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Totals & Payment Summary */}
            <div className="py-2.5 border-b border-dashed border-slate-400 space-y-1 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-600">Subtotal:</span>
                <span className="tabular-nums">{formatRupiah(transaction.totalAmount)}</span>
              </div>

              {transaction.discount > 0 && (
                <div className="flex justify-between text-rose-600">
                  <span>Diskon:</span>
                  <span className="tabular-nums">- {formatRupiah(transaction.discount)}</span>
                </div>
              )}

              <div className="flex justify-between text-xs font-bold pt-1 border-t border-slate-200">
                <span>TOTAL TAGIHAN:</span>
                <span className="tabular-nums text-slate-950 font-bold">
                  {formatRupiah(transaction.grandTotal)}
                </span>
              </div>

              <div className="flex justify-between text-slate-700">
                <span>Telah Dibayar:</span>
                <span className="tabular-nums">{formatRupiah(transaction.paidAmount)}</span>
              </div>

              <div className="flex justify-between font-bold text-slate-950 pt-1">
                <span>SISA TAGIHAN:</span>
                <span className={`tabular-nums ${remaining > 0 ? 'text-amber-800' : 'text-emerald-800'}`}>
                  {formatRupiah(remaining)}
                </span>
              </div>

              <div className="flex justify-between pt-1 text-[10px]">
                <span className="text-slate-500">Status Bayar:</span>
                <span className="uppercase font-bold tracking-wider">
                  {transaction.paymentStatus === 'lunas'
                    ? 'LUNAS'
                    : transaction.paymentStatus === 'sebagian'
                    ? 'DP (SEBAGIAN)'
                    : 'BELUM BAYAR'}
                </span>
              </div>
            </div>

            {/* Barcode & Footer Notice */}
            <div className="pt-3 text-center space-y-2">
              {/* Simulated barcode */}
              <div className="flex justify-center items-center py-1 gap-[2px] opacity-80 h-7 overflow-hidden">
                {[...Array(35)].map((_, i) => (
                  <div
                    key={i}
                    className="bg-slate-900 h-full"
                    style={{ width: i % 3 === 0 ? '3px' : i % 2 === 0 ? '1px' : '2px' }}
                  />
                ))}
              </div>
              <p className="text-[9px] text-slate-500 tracking-widest">{transaction.id}</p>

              <p className="text-[10px] text-slate-600 leading-tight">
                {settings.receiptFooter || 'Cucian bersih, rapi & higienis.'}
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons Bar */}
        <div className="p-4 bg-white border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 no-print">
          <div className="flex items-center gap-2">
            <button
              onClick={handleWhatsApp}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 rounded-lg border border-emerald-200 transition-colors cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Buka WhatsApp</span>
            </button>
            <button
              onClick={handleCopyText}
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              {copiedWA ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedWA ? 'Tersalin!' : 'Salin Teks Nota'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak Struk Sekarang</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
