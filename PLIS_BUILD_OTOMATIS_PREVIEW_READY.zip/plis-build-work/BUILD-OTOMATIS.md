# PLIS — Paket sumber untuk build otomatis GitHub Actions

Paket ini sengaja tidak menyertakan `.github/workflows/`. Unggah ZIP ini sebagai satu berkas ke repositori GitHub, lalu buat file workflow secara terpisah di `.github/workflows/build-preview.yml` menggunakan file workflow yang disediakan bersama paket.

Workflow akan mencari ZIP sumber di root repositori, mengekstraknya di runner GitHub, mencari `package.json`, memasang dependensi, menjalankan `npm run build`, mengemas isi `dist/` menjadi `PLIS-dist.zip`, dan menerbitkan preview melalui GitHub Pages.

## Catatan
- Jangan mengekstrak ZIP ini di HP. Unggah ZIP ini ke repositori sebagai satu berkas.
- File workflow harus dibuat di repositori pada `.github/workflows/build-preview.yml`; GitHub Actions tidak menjalankan workflow yang hanya berada di dalam ZIP.
- Setelah workflow sukses, unduh `PLIS-dist-zip` pada bagian Artifacts dari halaman run Actions. Preview tersedia melalui deployment GitHub Pages.
- Build aktual belum diverifikasi; jalankan workflow di GitHub untuk mengonfirmasi hasil.
