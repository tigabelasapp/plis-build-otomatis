# PLIS — Penggilas Laundry Information System

Aplikasi web modern untuk manajemen operasional usaha laundry terpadu: kasir (POS), pelacakan progres pengerjaan bertingkat independen per-item, manajemen pelanggan, termin pembayaran, pencatatan pengeluaran, cetak struk termal (58mm/80mm), kirim nota WhatsApp, dan laporan keuangan.

---

## 🚀 Cara Menjalankan di Komputer / Laptop Lokal

### 1. Prasyarat
Pastikan komputer Anda sudah terpasang:
- **Node.js** (Versi 18 atau lebih baru) — Unduh di [nodejs.org](https://nodejs.org/)
- **npm** (otomatis terpasang bersama Node.js)

### 2. Langkah Instalasi & Menjalankan

1. **Ekstrak berkas ZIP** yang telah Anda unduh dari Google AI Studio.
2. Buka folder proyek tersebut di **Terminal** (Mac/Linux) atau **Command Prompt / PowerShell** (Windows), atau buka di **VS Code**.
3. Pasang semua dependensi dengan menjalankan perintah:
   ```bash
   npm install
   ```
4. Jalankan server pengembang lokal:
   ```bash
   npm run dev
   ```
5. Buka peramban (browser) Anda dan akses alamat:
   ```
   http://localhost:3000
   ```
   Aplikasi laundry PLIS siap digunakan secara penuh!

---

## 🛠️ Perintah Berguna Lainnya

- **Membangun versi produksi (Build)**:
  ```bash
  npm run build
  ```
  Hasil build siap rilis akan berada di dalam folder `dist/` untuk diunggah ke hosting (seperti Vercel, Netlify, Cloudflare Pages, atau VPS).

- **Menjalankan preview hasil build**:
  ```bash
  npm run preview
  ```

---

## 📁 Struktur Berkas Proyek

```
├── index.html                   # Entry point web & meta branding
├── package.json                 # Daftar library & dependensi proyek
├── vite.config.ts               # Konfigurasi bundler Vite & Tailwind
├── tsconfig.json                # Konfigurasi TypeScript
├── public/                      # Asset statis, favicon & ikon PWA
└── src/
    ├── main.tsx                 # Entry point aplikasi React
    ├── App.tsx                  # Komponen induk navigasi & layout
    ├── index.css                # Styling global Tailwind CSS
    ├── types/                   # Definisi tipe TypeScript
    ├── data/                    # Data awal bawaan sistem
    ├── context/                 # Manajemen state terpusat (LaundryContext)
    ├── utils/                   # Format rupiah, tanggal, ekspor CSV, pesan WhatsApp
    └── components/
        ├── layout/              # Navbar, Sidebar, Mobile Drawer
        ├── modals/              # Modal transaksi baru, struk kasir, detail nota
        ├── views/               # 9 Tampilan menu utama aplikasi
        └── common/              # Komponen visual pembantu
```
